<template>
    <swiper :options="swiperOptions">
      <swiper-slide v-for="(slide, index) in slides" :key="index">
        <div class="carousel-slide">
          <img :src="slide.image" alt="Slide {{ index + 1 }}" />
        </div>
      </swiper-slide>
      <div class="swiper-button-prev"></div>
      <div class="swiper-button-next"></div>
    </swiper>
  </template>
  
  <script>
  import 'swiper/css/swiper.css';
  import { Swiper, SwiperSlide } from 'vue-awesome-swiper';
  
  export default {
    components: {
      Swiper,
      SwiperSlide,
    },
    data() {
      return {
        swiperOptions: {
          loop: true,
          navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
          },
        },
        slides: [
          { image: 'URL_DE_LA_IMAGEN_1' },
          { image: 'URL_DE_LA_IMAGEN_2' },
          { image: 'URL_DE_LA_IMAGEN_3' },
          // Agrega más imágenes según tus necesidades
        ],
      };
    },
  };
  </script>
  
  <style scoped>
  .carousel-slide {
    width: 100%;
    height: 300px; /* Ajusta la altura según tus necesidades */
    display: flex;
    justify-content: center;
    align-items: center;
  }
  
  /* Puedes agregar estilos personalizados para tu logo aquí */
  </style>
  