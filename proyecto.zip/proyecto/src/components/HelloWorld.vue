<template>
  <div>
    <nav class="navbar" style="background-color: #87CEEB">
      <ul>
        <li>Nosotros</li>
        <li>Contactenos</li>
        <li>Contactenos</li>
        <li>Inicio</li>
      </ul>
    </nav>
    <img src="portada.jpg" alt="Portada" />
    <div class="card-container">
      <div class="card">
        <h3>Card 1</h3>
        <p>Información de la empresa de maeting</p>
      </div>
      <div class="card">
        <h3>Card 2</h3>
        <p>Información de la empresa de marketing</p>
      </div>
      <div class="card">
        <h3>Card 3</h3>
        <p>Información de la empresa de marketing</p>
      </div>
      <div class="card">
        <h3>Card 4</h3>
        <p>Información de la empresa de marketing</p>
      </div>
      <div class="card">
        <h3>Card 5</h3>
        <p>Información de la empresa de marketing</p>
      </div>
      <div class="card">
        <h3>Card 6</h3>
        <p>Información de la empresa de marketing</p>
      </div>
      <div class="card">
        <h3>Card 7</h3>
        <p>Información de la empresa de marketing</p>
      </div>
      <div class="card">
        <h3>Card 8</h3>
        <p>Información de la empresa de marketing</p>
      </div>
    </div>
    <form>
      <!-- Formulario aquí -->
    </form>
    <footer class="footer" style="background-color: #87CEEB; color: white">
      <p>Pie de página</p>
    </footer>
  </div>
</template>
<style>
.navbar {
  
  padding: 10px 0;
  color: rgb(17, 43, 160);
}

.nav-link {
  margin-left: 20px;
  text-decoration: none;
  color: rgb(10, 6, 103);
}

.nav-link:hover {
  text-decoration: underline;
}

.marketing-cards {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
}

.card {
  width: calc(25% - 20px); /* Alinea 4 tarjetas por fila con espacio entre ellas */
  margin-bottom: 20px;
  padding: 20px;
  border: 1px solid #ccc;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  text-align: center;
}

.card img {
  max-width: 100%;
  height: auto;
}

.card h2 {
  margin-top: 10px;
  font-size: 18px;
}

.card p {
  margin-top: 10px;
}

.card a {
  display: block;
  margin-top: 10px;
  text-decoration: none;
  color: #007BFF;
  font-weight: bold;
}
.footer {
  padding: 10px 0;
  color: white;
}
</style>