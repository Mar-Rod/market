<script setup>

import TheWelcome from './components/TheWelcome.vue'
</script>
<template>
  <nav class="navbar" style="background-color: #1022e8;">
    <div class="container">
      <router-link to="/" class="navbar-brand">Inicio</router-link>
      <router-link to="/nosotros" class="nav-link">Servicio</router-link>
      
      <router-link to="/contactenos" class="nav-link">Nosotros</router-link>
      <router-link to="/contactenos" class="nav-link">Contáctenos</router-link>
    </div>
  </nav>


<!-- Formulario -->
<div class="contact-form">
  <header class="page-header-ui page-header-ui-dark bg-gradient-primary-to-secondary">
        <div class="page-header-ui-content pt-10">
          <div class="container px-5">
            <div class="row gx-5 align-items-center">
              <div class="col-lg-6 aos-init aos-animate" data-aos="fade-up">
                <h1 class="page-header-ui-title">Agencia Digital en CDMX</h1>
                <p class="page-header-ui-text mb-5">Creamos estrategias tan únicas como tu marca, potenciando tus fortalezas y logrando que la audiencia se enamore de ti, enfocados en el crecimiento de tu negocio en internet.</p>
                <a class="btn btn-teal fw-500 me-2" href="#!">
                 Empezar
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-right ms-2">
                    <line x1="5" y1="12" x2="19" y2="12"></line>
                    <polyline points="12 5 19 12 12 19"></polyline>
                  </svg>
                </a>
                <a class="btn btn-link fw-500" href="#!">Saber más...</a>
                
              </div>
              <div class="col-lg-6 d-none d-lg-block aos-init aos-animate" data-aos="fade-up" data-aos-delay="100"><img class="img-fluid" src="../IMG/tipo-de-seo-on-page.svg"></div>
            </div>
          </div>
        </div>
        <div class="svg-border-rounded text-white">
          <!-- Rounded SVG Border-->
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 144.54 17.34" preserveAspectRatio="none" fill="currentColor">
            <path d="M144.54,17.34H0V0H144.54ZM0,0S32.36,17.34,72.27,17.34,144.54,0,144.54,0"></path>
          </svg>
        </div>
      </header>
      <div class="modal fade bg-white" id="templatemo_search" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="w-100 pt-1 mb-5 text-right">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="" method="get" class="modal-content modal-body border-0 p-0">
                <div class="input-group mb-2">
                    <input type="text" class="form-control" id="inputModalSearch" name="q" placeholder="Search ...">
                    <button type="submit" class="input-group-text bg-success text-light">
                        <i class="fa fa-fw fa-search text-white"></i>
                    </button>
                </div>
            </form>
        </div>
    </div>
    <div class="container px-5">
          <div class="row gx-5 my-10">
            <div class="col-lg-6 mb-5">
              <div class="d-flex h-100">
                <div class="icon-stack flex-shrink-0 bg-teal text-white"><svg class="svg-inline--fa fa-question fa-w-12" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="question" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512" data-fa-i2svg="">
                    <path fill="currentColor" d="M202.021 0C122.202 0 70.503 32.703 29.914 91.026c-7.363 10.58-5.093 25.086 5.178 32.874l43.138 32.709c10.373 7.865 25.132 6.026 33.253-4.148 25.049-31.381 43.63-49.449 82.757-49.449 30.764 0 68.816 19.799 68.816 49.631 0 22.552-18.617 34.134-48.993 51.164-35.423 19.86-82.299 44.576-82.299 106.405V320c0 13.255 10.745 24 24 24h72.471c13.255 0 24-10.745 24-24v-5.773c0-42.86 125.268-44.645 125.268-160.627C377.504 66.256 286.902 0 202.021 0zM192 373.459c-38.196 0-69.271 31.075-69.271 69.271 0 38.195 31.075 69.27 69.271 69.27s69.271-31.075 69.271-69.271-31.075-69.27-69.271-69.27z"></path>
                  </svg><!-- <i class="fas fa-question"></i> Font Awesome fontawesome.com -->
                </div>
                <div class="ms-4">
                  <h5 class="text-white">Gestión de Reputación en Línea:</h5>
                  <p class="text-white-50">Monitoreamos y gestionamos la reputación en línea de tu empresa, asegurando que las opiniones positivas prevalezcan y se aborden las negativas.</p>
                </div>
              </div>
            </div>
            <div class="col-lg-6 mb-5">
              <div class="d-flex h-100">
                <div class="icon-stack flex-shrink-0 bg-teal text-white"><svg class="svg-inline--fa fa-question fa-w-12" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="question" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512" data-fa-i2svg="">
                    <path fill="currentColor" d="M202.021 0C122.202 0 70.503 32.703 29.914 91.026c-7.363 10.58-5.093 25.086 5.178 32.874l43.138 32.709c10.373 7.865 25.132 6.026 33.253-4.148 25.049-31.381 43.63-49.449 82.757-49.449 30.764 0 68.816 19.799 68.816 49.631 0 22.552-18.617 34.134-48.993 51.164-35.423 19.86-82.299 44.576-82.299 106.405V320c0 13.255 10.745 24 24 24h72.471c13.255 0 24-10.745 24-24v-5.773c0-42.86 125.268-44.645 125.268-160.627C377.504 66.256 286.902 0 202.021 0zM192 373.459c-38.196 0-69.271 31.075-69.271 69.271 0 38.195 31.075 69.27 69.271 69.27s69.271-31.075 69.271-69.271-31.075-69.27-69.271-69.27z"></path>
                  </svg><!-- <i class="fas fa-question"></i> Font Awesome fontawesome.com -->
                </div>
                <div class="ms-4">
                  <h5 class="text-white">Análisis de Datos y Métricas</h5>
                  <p class="text-white-50">Utilizamos análisis avanzados para medir el rendimiento de tus campañas y ajustar estrategias para lograr resultados óptimos.</p>
                </div>
              </div>
            </div>
            <div class="col-lg-6 mb-5 mb-lg-0">
              <div class="d-flex h-100">
                <div class="icon-stack flex-shrink-0 bg-teal text-white"><svg class="svg-inline--fa fa-question fa-w-12" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="question" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512" data-fa-i2svg="">
                    <path fill="currentColor" d="M202.021 0C122.202 0 70.503 32.703 29.914 91.026c-7.363 10.58-5.093 25.086 5.178 32.874l43.138 32.709c10.373 7.865 25.132 6.026 33.253-4.148 25.049-31.381 43.63-49.449 82.757-49.449 30.764 0 68.816 19.799 68.816 49.631 0 22.552-18.617 34.134-48.993 51.164-35.423 19.86-82.299 44.576-82.299 106.405V320c0 13.255 10.745 24 24 24h72.471c13.255 0 24-10.745 24-24v-5.773c0-42.86 125.268-44.645 125.268-160.627C377.504 66.256 286.902 0 202.021 0zM192 373.459c-38.196 0-69.271 31.075-69.271 69.271 0 38.195 31.075 69.27 69.271 69.27s69.271-31.075 69.271-69.271-31.075-69.27-69.271-69.27z"></path>
                  </svg><!-- <i class="fas fa-question"></i> Font Awesome fontawesome.com -->
                </div>
                <div class="ms-4">
                  <h5 class="text-white">Estrategia de Marketing Internacional</h5>
                  <p class="text-white-50">Ayudamos a las empresas a expandirse globalmente, adaptando sus estrategias de marketing a mercados internacionales.</p>
                </div>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="d-flex h-100">
                <div class="icon-stack flex-shrink-0 bg-teal text-white"><svg class="svg-inline--fa fa-question fa-w-12" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="question" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512" data-fa-i2svg="">
                    <path fill="currentColor" d="M202.021 0C122.202 0 70.503 32.703 29.914 91.026c-7.363 10.58-5.093 25.086 5.178 32.874l43.138 32.709c10.373 7.865 25.132 6.026 33.253-4.148 25.049-31.381 43.63-49.449 82.757-49.449 30.764 0 68.816 19.799 68.816 49.631 0 22.552-18.617 34.134-48.993 51.164-35.423 19.86-82.299 44.576-82.299 106.405V320c0 13.255 10.745 24 24 24h72.471c13.255 0 24-10.745 24-24v-5.773c0-42.86 125.268-44.645 125.268-160.627C377.504 66.256 286.902 0 202.021 0zM192 373.459c-38.196 0-69.271 31.075-69.271 69.271 0 38.195 31.075 69.27 69.271 69.27s69.271-31.075 69.271-69.271-31.075-69.27-69.271-69.27z"></path>
                  </svg><!-- <i class="fas fa-question"></i> Font Awesome fontawesome.com -->
                </div>
                <div class="ms-4">
                  <h5 class="text-white">Estrategia de Marca y Posicionamiento?</h5>
                  <p class="text-white-50">Definimos la identidad de tu marca y la posicionamos de manera única en el mercado para destacar entre la competencia.</p>
                </div>
              </div>
            </div>
          </div>
          <div class="row gx-5 justify-content-center text-center">
            <div class="col-lg-8">
             
              <h2 class="text-white">Asesoría en Estrategia de Marketing</h2>
              <p class="lead text-white-50 mb-5">Brindamos consultoría para ayudarte a desarrollar una estrategia de marketing efectiva que puedas implementar internamente.!</p>
              <a class="btn btn-teal fw-500" href="#!">¡Quiero empezar ya!</a>
            </div>
          </div>
        </div>
        <div class="svg-border-rounded text-white">
          <!-- Rounded SVG Border-->
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 144.54 17.34" preserveAspectRatio="none" fill="currentColor">
            <path d="M144.54,17.34H0V0H144.54ZM0,0S32.36,17.34,72.27,17.34,144.54,0,144.54,0"></path>
          </svg>
        </div>
    <div class="background">
                <div class="containe">
                  <div class="panel pricing-table">
                    
                    <div class="pricing-plan">
                        <img src="../IMG/conversion-inbound-marketing.svg" class="pricing-img">
                        <h2 class="pricing-header">Plan de Marketing Digital Integral</h2>
                        <ul class="pricing-features">
                          <li class="pricing-features-item">Estrategia de marketing digital completa que abarca SEO</li>
                          <li class="pricing-features-item">Publicidad en línea, redes sociales, email marketing y análisis de datos</li>
                        </ul>
                        <span class="pricing-price">$500</span>
                        <a href="#/" class="pricing-button">PROBAR</a>
                      </div>
                      
                    <div class="pricing-plan">
                      <img src="../IMG/atraccion-inbound-marketing.svg" alt="" class="pricing-img">
                      <h2 class="pricing-header">Plan de SEO</h2>
                      <ul class="pricing-features">
                        <li class="pricing-features-item">Ranking de un sitio web en los motores de búsqueda</li>
                        <li class="pricing-features-item">Investigación de palabras clave, optimización de contenido y creación de enlaces.</li>
                      </ul>
                      <span class="pricing-price">$450</span>
                      <a href="#/" class="pricing-button">ELEGIR</a>
                    </div>
                    
                    <div class="pricing-plan">
                      <img src="../IMG/imgMarketingDeContenidos.svg" class="pricing-img">
                      <h2 class="pricing-header">Plan de Redes Sociales</h2>
                      <ul class="pricing-features">
                        <li class="pricing-features-item">Gestión de perfiles en múltiples plataformas</li>
                        <li class="pricing-features-item">Creación de contenido, publicidad y participación de la comunidad.</li>
                      </ul>
                      <span class="pricing-price">GRATIS</span>
                      <a href="#/" class="pricing-button is-featured">LO QUIERO</a>
                    </div>
                    
                    <div class="pricing-plan">
                      <img src="../IMG/imgCierreyFidelizacion.svg" alt="" class="pricing-img">
                      <h2 class="pricing-header">Plan de Desarrollo Web</h2>
                      <ul class="pricing-features">
                        <li class="pricing-features-item">Diseño y desarrollo de sitios web optimizados para SEO</li>
                        <li class="pricing-features-item">Experiencias de usuario excepcionales.</li>
                      </ul>
                      <span class="pricing-price">$400</span>
                      <a href="#/" class="pricing-button">PROBAR</a>
                    </div>
                    
                  </div>
                </div>
              </div>
      <!-- Aquí puedes agregar tu formulario -->
    </div>

    <!-- Pie de página -->
    <footer class="footer" style="background-color: #03151d; color: white;">
      <div class="container">
        <footer class="bg-dark text-light py-5">
        <div class="container">
            <div class="row">
                <div class="col md-4">
                    <div class="footer-content">
                        <h3 class="footer-title">Información de contacto</h3>
                        <small>Redes sociales</small>
                        <div class="social-link">
                            <ul class="list-unstyled d-flex">
                                <li><a href="#"><i class="fab fa-facebook"></i></a></li> <li><a href="#"><i class="fab fa-instagram"></i></a></li> <li><a href="#"><i class="fab fa-linkedin"></i></a></li> <li><a href="#"><i class="fab fa-google"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div><!--col-md-3-->
                <div class="col md-2">
                    <div class="footer-product">
                        <h2 class="footer-title">Enlaces de navegación</h2>
                        <div class="items">
                            <ul class="list-unstyled">
                              <li>Ubicación</li>
                              <li>Enlaces de interés</li>
                              <li>Información de pagos y seguridad</li>
                              <li>Declaración de responsabilidad</li>
                            </ul>
                        </div>
                    </div>
                </div><!--col-md-2-->
                <div class="col md-2">
                    <div class="footer-product">
                        <h2 class="footer-title">Mapa del sitio:</h2>
                        <div class="items">
                            <ul class="list-unstyled">
                              <li>Ubicación</li>
                              <li>Enlaces de interés</li>
                              <li>Información de pagos y seguridad</li>
                              <li>Declaración de responsabilidad</li>
                            </ul>
                        </div>
                    </div>
                </div><!--col-md-2-->
                <div class="col md-2">
                    <div class="footer-product">
                        <h2 class="footer-title">Acreditaciones y certificaciones</h2>
                        <div class="items">
                            <ul class="list-unstyled">
                              <li>Ubicación</li>
                              <li>Enlaces de interés</li>
                              <li>Información de pagos y seguridad</li>
                              <li>Declaración de responsabilidad</li>
                            </ul>
                        </div>
                    </div>
                </div><!--col-md-2-->
                <div class="col-md-2">
                    <div class="footer-product">
                        <h2 class="footer-title">Políticas y términos legales</h2>
                        <div class="items">
                            <ul class="list-unstyled">
                                <li>Ubicación</li>
                                <li>Enlaces de interés</li>
                                <li>Información de pagos y seguridad</li>
                                <li>Declaración de responsabilidad</li>
                            </ul>
                        </div>
                    </div>
                </div><!--col-md-3-->
            </div><!--row-->
        </div>
        <div class="footer-bottom py-5">
            <div class="container">
               <div class="footer-bottom-content">
                <small>Copyright © MARKETFUSION 2023</small>
                <small>TERMINOS Y CONDICIONES</small></div>
               </div>
        </div>
     

    </footer><!-- Contenido del pie de página -->
      </div>
    </footer>
 
  
  <div class="marketing-cards">
    <div class="card" v-for="(company, index) in companies" :key="index">
      <img class="img-fluid" src="../IMG/tipo-de-seo-on-page.svg">
      <h2>{{ company.name }}</h2>
      <p>{{ company.description }}</p>
      <a :href="company.website" target="_blank">Lo quiero</a>
    </div>
  </div>
  
</template>

<script>
export default {
  data() {
    return {
      companies: [
        {
          name: 'Descrip 1',
          logo: 'URL_DEL_LOGO_1',
          description: 'Descripción  1',
          website: 'URL_DEL_SITIO_1',
        },
        {
          name: 'Descrip 2',
          logo: 'URL_DEL_LOGO_2',
          description: 'Descripción  2',
          website: 'URL_DEL_SITIO_2',
        },
        {
          name: 'Descrip 3',
          logo: 'URL_DEL_LOGO_3',
          description: 'Descripción  3',
          website: 'URL_DEL_SITIO_3',
        },
        {
          name: 'Descrip 4',
          logo: 'URL_DEL_LOGO_4',
          description: 'Descripción  4',
          website: 'URL_DEL_SITIO_4',
        },
        {
          name: 'Descrip 5',
          logo: 'URL_DEL_LOGO_5',
          description: 'Descripción  5',
          website: 'URL_DEL_SITIO_5',
        },
        {
          name: 'Descrip 6',
          logo: 'URL_DEL_LOGO_6',
          description: 'Descripción  6',
          website: 'URL_DEL_SITIO_6',
        },
        {
          name: 'Descrip 7',
          logo: 'URL_DEL_LOGO_7',
          description: 'Descripción  7',
          website: 'URL_DEL_SITIO_7',
        },
        {
          name: 'Descrip 8',
          logo: 'URL_DEL_LOGO_8',
          description: 'Descripción  8',
          website: 'URL_DEL_SITIO_8',
        },
      ],
    };
  },
};
</script>

<style scoped>


.navbar {
  padding: 10px 0;
  color: white;
}

.nav-link {
  margin-left: 20px;
  text-decoration: none;
  color: white;
}

.nav-link:hover {
  text-decoration: underline;
}


.marketing-cards {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
}

.card {
  width: calc(25% - 20px); /* Alinea 4 tarjetas por fila con espacio entre ellas */
  margin-bottom: 20px;
  padding: 20px;
  border: 1px solid #ccc;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  text-align: center;
}

.card img {
  max-width: 100%;
  height: auto;
}

.card h2 {
  margin-top: 10px;
  font-size: 18px;
}

.card p {
  margin-top: 10px;
}

.card a {
  display: block;
  margin-top: 10px;
  text-decoration: none;
  color: #007BFF;
  font-weight: bold;
}
:root {
    --bs-blue: #0061f2;
    --bs-indigo: #5800e8;
    --bs-purple: #6900c7;
    --bs-pink: #e30059;
    --bs-red: #e81500;
    --bs-orange: #f76400;
    --bs-yellow: #f4a100;
    --bs-green: #00ac69;
    --bs-teal: #00ba94;
    --bs-cyan: #00cfd5;
    --bs-white: #fff;
    --bs-gray: #69707a;
    --bs-gray-dark: #363d47;
    --bs-gray-100: #f2f6fc;
    --bs-gray-200: #e0e5ec;
    --bs-gray-300: #d4dae3;
    --bs-gray-400: #c5ccd6;
    --bs-gray-500: #a7aeb8;
    --bs-gray-600: #69707a;
    --bs-gray-700: #4a515b;
    --bs-gray-800: #363d47;
    --bs-gray-900: #212832;
    --bs-primary: #0061f2;
    --bs-secondary: #6900c7;
    --bs-success: #00ac69;
    --bs-info: #00cfd5;
    --bs-warning: #f4a100;
    --bs-danger: #e81500;
    --bs-light: #f2f6fc;
    --bs-dark: #212832;
    --bs-black: #000;
    --bs-white: #fff;
    --bs-red: #e81500;
    --bs-orange: #f76400;
    --bs-yellow: #f4a100;
    --bs-green: #00ac69;
    --bs-teal: #00ba94;
    --bs-cyan: #00cfd5;
    --bs-blue: #0061f2;
    --bs-indigo: #5800e8;
    --bs-purple: #6900c7;
    --bs-pink: #e30059;
    --bs-red-soft: #f1e0e3;
    --bs-orange-soft: #f3e7e3;
    --bs-yellow-soft: #f2eee3;
    --bs-green-soft: #daefed;
    --bs-teal-soft: #daf0f2;
    --bs-cyan-soft: #daf2f8;
    --bs-blue-soft: #dae7fb;
    --bs-indigo-soft: #e3ddfa;
    --bs-purple-soft: #e4ddf7;
    --bs-pink-soft: #f1ddec;
    --bs-primary-soft: #dae7fb;
    --bs-secondary-soft: #e4ddf7;
    --bs-success-soft: #daefed;
    --bs-info-soft: #daf2f8;
    --bs-warning-soft: #f2eee3;
    --bs-danger-soft: #f1e0e3;
    --bs-primary-rgb: 0, 97, 242;
    --bs-secondary-rgb: 105, 0, 199;
    --bs-success-rgb: 0, 172, 105;
    --bs-info-rgb: 0, 207, 213;
    --bs-warning-rgb: 244, 161, 0;
    --bs-danger-rgb: 232, 21, 0;
    --bs-light-rgb: 242, 246, 252;
    --bs-dark-rgb: 33, 40, 50;
    --bs-black-rgb: 0, 0, 0;
    --bs-white-rgb: 255, 255, 255;
    --bs-red-rgb: 232, 21, 0;
    --bs-orange-rgb: 247, 100, 0;
    --bs-yellow-rgb: 244, 161, 0;
    --bs-green-rgb: 0, 172, 105;
    --bs-teal-rgb: 0, 186, 148;
    --bs-cyan-rgb: 0, 207, 213;
    --bs-blue-rgb: 0, 97, 242;
    --bs-indigo-rgb: 88, 0, 232;
    --bs-purple-rgb: 105, 0, 199;
    --bs-pink-rgb: 227, 0, 89;
    --bs-red-soft-rgb: 241, 224, 227;
    --bs-orange-soft-rgb: 243, 231, 227;
    --bs-yellow-soft-rgb: 242, 238, 227;
    --bs-green-soft-rgb: 218, 239, 237;
    --bs-teal-soft-rgb: 218, 240, 242;
    --bs-cyan-soft-rgb: 218, 242, 248;
    --bs-blue-soft-rgb: 218, 231, 251;
    --bs-indigo-soft-rgb: 227, 221, 250;
    --bs-purple-soft-rgb: 228, 221, 247;
    --bs-pink-soft-rgb: 241, 221, 236;
    --bs-primary-soft-rgb: 218, 231, 251;
    --bs-secondary-soft-rgb: 228, 221, 247;
    --bs-success-soft-rgb: 218, 239, 237;
    --bs-info-soft-rgb: 218, 242, 248;
    --bs-warning-soft-rgb: 242, 238, 227;
    --bs-danger-soft-rgb: 241, 224, 227;
    --bs-white-rgb: 255, 255, 255;
    --bs-black-rgb: 0, 0, 0;
    --bs-body-color-rgb: 105, 112, 122;
    --bs-body-bg-rgb: 242, 246, 252;
    --bs-font-sans-serif: "Metropolis", -apple-system, BlinkMacSystemFont,
      "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif, "Apple Color Emoji",
      "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
    --bs-font-monospace: SFMono-Regular, Menlo, Monaco, Consolas,
      "Liberation Mono", "Courier New", monospace;
    --bs-gradient: linear-gradient(
      180deg,
      rgba(255, 255, 255, 0.15),
      rgba(255, 255, 255, 0)
    );
    --bs-body-font-family: Metropolis, -apple-system, BlinkMacSystemFont, Segoe UI,
      Roboto, Helvetica Neue, Arial, sans-serif, Apple Color Emoji, Segoe UI Emoji,
      Segoe UI Symbol, Noto Color Emoji;
    --bs-body-font-size: 1rem;
    --bs-body-font-weight: 400;
    --bs-body-line-height: 1.5;
    --bs-body-color: #69707a;
    --bs-body-bg: #f2f6fc;
  }
  *,
  ::after,
  ::before {
    box-sizing: border-box;
  }
  @media (prefers-reduced-motion: no-preference) {
    :root {
      scroll-behavior: smooth;
    }
  }
  body {
    margin: 0;
    font-family: var(--bs-body-font-family);
    font-size: var(--bs-body-font-size);
    font-weight: var(--bs-body-font-weight);
    line-height: var(--bs-body-line-height);
    color: var(--bs-body-color);
    text-align: var(--bs-body-text-align);
    background-color: var(--bs-body-bg);
    -webkit-text-size-adjust: 100%;
    -webkit-tap-highlight-color: transparent;
  }
  hr {
    margin: 1rem 0;
    color: inherit;
    background-color: currentColor;
    border: 0;
    opacity: 0.25;
  }
  hr:not([size]) {
    height: 1px;
  }
  .h1,
  .h2,
  .h3,
  .h4,
  .h5,
  .h6,
  h1,
  h2,
  h3,
  h4,
  h5,
  h6 {
    margin-top: 0;
    margin-bottom: 0.5rem;
    font-weight: 700;
    line-height: 1.2;
    color: #000000;
  }
  .h1,
  h1 {
    font-size: calc(1.275rem + 0.3vw);
  }
  @media (min-width: 1200px) {
    .h1,
    h1 {
      font-size: 1.5rem;
    }
  }
  .h2,
  h2 {
    font-size: calc(1.265rem + 0.18vw);
  }
  @media (min-width: 1200px) {
    .h2,
    h2 {
      font-size: 1.4rem;
    }
  }
  .h3,
  h3 {
    font-size: calc(1.255rem + 0.06vw);
  }
  @media (min-width: 1200px) {
    .h3,
    h3 {
      font-size: 1.3rem;
    }
  }
  .h4,
  h4 {
    font-size: 1.2rem;
  }
  .h5,
  h5 {
    font-size: 1.1rem;
  }
  .h6,
  h6 {
    font-size: 1rem;
  }
  p {
    margin-top: 0;
    margin-bottom: 1rem;
  }
  .small,
  small {
    font-size: 0.875em;
  }
  a {
    color: #AC6DBF;
    text-decoration: none;
  }
  a:hover {
    color: #01989F;
    text-decoration: underline;
  }
  a:not([href]):not([class]),
  a:not([href]):not([class]):hover {
    color: inherit;
    text-decoration: none;
  }
  code,
  pre {
    font-family: var(--bs-font-monospace);
    font-size: 1em;
    direction: ltr;
    unicode-bidi: bidi-override;
  }
  pre {
    display: block;
    margin-top: 0;
    margin-bottom: 1rem;
    overflow: auto;
    font-size: 0.875em;
    color: #2a5899;
  }
  pre code {
    font-size: inherit;
    color: inherit;
    word-break: normal;
  }
  code {
    font-size: 0.875em;
    color: #54136c;
    word-wrap: break-word;
  }
  a > code {
    color: inherit;
  }
  img,
  svg {
    vertical-align: middle;
  }
  [role="button"] {
    cursor: pointer;
  }
  [list]::-webkit-calendar-picker-indicator {
    display: none;
  }
  [type="button"],
  [type="reset"],
  [type="submit"] {
    -webkit-appearance: button;
  }
  [type="button"]:not(:disabled),
  [type="reset"]:not(:disabled),
  [type="submit"]:not(:disabled) {
    cursor: pointer;
  }
  ::-moz-focus-inner {
    padding: 0;
    border-style: none;
  }
  ::-webkit-datetime-edit-day-field,
  ::-webkit-datetime-edit-fields-wrapper,
  ::-webkit-datetime-edit-hour-field,
  ::-webkit-datetime-edit-minute,
  ::-webkit-datetime-edit-month-field,
  ::-webkit-datetime-edit-text,
  ::-webkit-datetime-edit-year-field {
    padding: 0;
  }
  ::-webkit-inner-spin-button {
    height: auto;
  }
  [type="search"] {
    outline-offset: -2px;
    -webkit-appearance: textfield;
  }
  ::-webkit-search-decoration {
    -webkit-appearance: none;
  }
  ::-webkit-color-swatch-wrapper {
    padding: 0;
  }
  ::-webkit-file-upload-button {
    font: inherit;
  }
  ::file-selector-button {
    font: inherit;
  }
  ::-webkit-file-upload-button {
    font: inherit;
    -webkit-appearance: button;
  }
  [hidden] {
    display: none !important;
  }
  .lead {
    color: #ffffff;
    font-size: 1.1rem;
    font-weight: 400;
  }
  .img-fluid {
    max-width: 100%;
    height: auto;
  }
  .container,
  .container-fluid,
  .container-lg,
  .container-md,
  .container-xl {
    width: 100%;
    padding-right: var(--bs-gutter-x, 0.75rem);
    padding-left: var(--bs-gutter-x, 0.75rem);
    margin-right: auto;
    margin-left: auto;
  }
  @media (min-width: 576px) {
    .container {
      max-width: 540px;
    }
  }
  @media (min-width: 768px) {
    .container,
    .container-md {
      max-width: 720px;
    }
  }
  @media (min-width: 992px) {
    .container,
    .container-lg,
    .container-md {
      max-width: 960px;
    }
  }
  @media (min-width: 1200px) {
    .container,
    .container-lg,
    .container-md,
    .container-xl {
      max-width: 1140px;
    }
  }
  @media (min-width: 1500px) {
    .container,
    .container-lg,
    .container-md,
    .container-xl {
      max-width: 1440px;
    }
  }
  .row {
    --bs-gutter-x: 1.5rem;
    --bs-gutter-y: 0;
    display: flex;
    flex-wrap: wrap;
    margin-top: calc(-1 * var(--bs-gutter-y));
    margin-right: calc(-0.5 * var(--bs-gutter-x));
    margin-left: calc(-0.5 * var(--bs-gutter-x));
  }
  .row > * {
    flex-shrink: 0;
    width: 100%;
    max-width: 100%;
    padding-right: calc(var(--bs-gutter-x) * 0.5);
    padding-left: calc(var(--bs-gutter-x) * 0.5);
    margin-top: var(--bs-gutter-y);
  }
  .col {
    flex: 1 0 0%;
  }
  .col-1 {
    flex: 0 0 auto;
    width: 8.33333333%;
  }
  .col-2 {
    flex: 0 0 auto;
    width: 16.66666667%;
  }
  .col-3 {
    flex: 0 0 auto;
    width: 25%;
  }
  .col-4 {
    flex: 0 0 auto;
    width: 33.33333333%;
  }
  .col-5 {
    flex: 0 0 auto;
    width: 41.66666667%;
  }
  .col-6 {
    flex: 0 0 auto;
    width: 50%;
  }
  .col-7 {
    flex: 0 0 auto;
    width: 58.33333333%;
  }
  .col-8 {
    flex: 0 0 auto;
    width: 66.66666667%;
  }
  .col-9 {
    flex: 0 0 auto;
    width: 75%;
  }
  .col-10 {
    flex: 0 0 auto;
    width: 83.33333333%;
  }
  .col-11 {
    flex: 0 0 auto;
    width: 91.66666667%;
  }
  .col-12 {
    flex: 0 0 auto;
    width: 100%;
  }
  .gx-0 {
    --bs-gutter-x: 0;
  }
  .gx-1 {
    --bs-gutter-x: 0.25rem;
  }
  .gx-2 {
    --bs-gutter-x: 0.5rem;
  }
  .gx-3 {
    --bs-gutter-x: 1rem;
  }
  .gx-4 {
    --bs-gutter-x: 1.5rem;
  }
  .gx-5 {
    --bs-gutter-x: 2.5rem;
  }
  .gx-10 {
    --bs-gutter-x: 6rem;
  }
  .gx-15 {
    --bs-gutter-x: 9rem;
  }
  @media (min-width: 768px) {
    .col-md {
      flex: 1 0 0%;
    }
    .col-md-1 {
      flex: 0 0 auto;
      width: 8.33333333%;
    }
    .col-md-2 {
      flex: 0 0 auto;
      width: 16.66666667%;
    }
    .col-md-3 {
      flex: 0 0 auto;
      width: 25%;
    }
    .col-md-4 {
      flex: 0 0 auto;
      width: 33.33333333%;
    }
    .col-md-5 {
      flex: 0 0 auto;
      width: 41.66666667%;
    }
    .col-md-6 {
      flex: 0 0 auto;
      width: 50%;
    }
    .col-md-7 {
      flex: 0 0 auto;
      width: 58.33333333%;
    }
    .col-md-8 {
      flex: 0 0 auto;
      width: 66.66666667%;
    }
    .col-md-9 {
      flex: 0 0 auto;
      width: 75%;
    }
    .col-md-10 {
      flex: 0 0 auto;
      width: 83.33333333%;
    }
    .col-md-11 {
      flex: 0 0 auto;
      width: 91.66666667%;
    }
    .col-md-12 {
      flex: 0 0 auto;
      width: 100%;
    }
    .gx-md-0 {
      --bs-gutter-x: 0;
    }
    .gx-md-1 {
      --bs-gutter-x: 0.25rem;
    }
    .gx-md-2 {
      --bs-gutter-x: 0.5rem;
    }
    .gx-md-3 {
      --bs-gutter-x: 1rem;
    }
    .gx-md-4 {
      --bs-gutter-x: 1.5rem;
    }
    .gx-md-5 {
      --bs-gutter-x: 2.5rem;
    }
    .gx-md-10 {
      --bs-gutter-x: 6rem;
    }
    .gx-md-15 {
      --bs-gutter-x: 9rem;
    }
  }
  @media (min-width: 992px) {
    .col-lg {
      flex: 1 0 0%;
    }
    .col-lg-1 {
      flex: 0 0 auto;
      width: 8.33333333%;
    }
    .col-lg-2 {
      flex: 0 0 auto;
      width: 16.66666667%;
    }
    .col-lg-3 {
      flex: 0 0 auto;
      width: 25%;
    }
    .col-lg-4 {
      flex: 0 0 auto;
      width: 33.33333333%;
    }
    .col-lg-5 {
      flex: 0 0 auto;
      width: 41.66666667%;
    }
    .col-lg-6 {
      flex: 0 0 auto;
      width: 50%;
    }
    .col-lg-7 {
      flex: 0 0 auto;
      width: 58.33333333%;
    }
    .col-lg-8 {
      flex: 0 0 auto;
      width: 66.66666667%;
    }
    .col-lg-9 {
      flex: 0 0 auto;
      width: 75%;
    }
    .col-lg-10 {
      flex: 0 0 auto;
      width: 83.33333333%;
    }
    .col-lg-11 {
      flex: 0 0 auto;
      width: 91.66666667%;
    }
    .col-lg-12 {
      flex: 0 0 auto;
      width: 100%;
    }
    .gx-lg-0 {
      --bs-gutter-x: 0;
    }
    .gx-lg-1 {
      --bs-gutter-x: 0.25rem;
    }
    .gx-lg-2 {
      --bs-gutter-x: 0.5rem;
    }
    .gx-lg-3 {
      --bs-gutter-x: 1rem;
    }
    .gx-lg-4 {
      --bs-gutter-x: 1.5rem;
    }
    .gx-lg-5 {
      --bs-gutter-x: 2.5rem;
    }
    .gx-lg-10 {
      --bs-gutter-x: 6rem;
    }
    .gx-lg-15 {
      --bs-gutter-x: 9rem;
    }
  }
  @media (min-width: 1200px) {
    .col-xl {
      flex: 1 0 0%;
    }
    .col-xl-1 {
      flex: 0 0 auto;
      width: 8.33333333%;
    }
    .col-xl-2 {
      flex: 0 0 auto;
      width: 16.66666667%;
    }
    .col-xl-3 {
      flex: 0 0 auto;
      width: 25%;
    }
    .col-xl-4 {
      flex: 0 0 auto;
      width: 33.33333333%;
    }
    .col-xl-5 {
      flex: 0 0 auto;
      width: 41.66666667%;
    }
    .col-xl-6 {
      flex: 0 0 auto;
      width: 50%;
    }
    .col-xl-7 {
      flex: 0 0 auto;
      width: 58.33333333%;
    }
    .col-xl-8 {
      flex: 0 0 auto;
      width: 66.66666667%;
    }
    .col-xl-9 {
      flex: 0 0 auto;
      width: 75%;
    }
    .col-xl-10 {
      flex: 0 0 auto;
      width: 83.33333333%;
    }
    .col-xl-11 {
      flex: 0 0 auto;
      width: 91.66666667%;
    }
    .col-xl-12 {
      flex: 0 0 auto;
      width: 100%;
    }
    .gx-xl-0 {
      --bs-gutter-x: 0;
    }
    .gx-xl-1 {
      --bs-gutter-x: 0.25rem;
    }
    .gx-xl-2 {
      --bs-gutter-x: 0.5rem;
    }
    .gx-xl-3 {
      --bs-gutter-x: 1rem;
    }
    .gx-xl-4 {
      --bs-gutter-x: 1.5rem;
    }
    .gx-xl-5 {
      --bs-gutter-x: 2.5rem;
    }
    .gx-xl-10 {
      --bs-gutter-x: 6rem;
    }
    .gx-xl-15 {
      --bs-gutter-x: 9rem;
    }
  }
  .btn {
    display: inline-block;
    font-weight: 400;
    line-height: 1;
    color: #69707a;
    text-align: center;
    vertical-align: middle;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    background-color: transparent;
    border: 1px solid transparent;
    padding: 0.875rem 1.125rem;
    font-size: 0.875rem;
    border-radius: 0.35rem;
    transition: color 0.15s ease-in-out, background-color 0.15s ease-in-out,
      border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
  }
  @media (prefers-reduced-motion: reduce) {
    .btn {
      transition: none;
    }
  }
  .btn:hover {
    color: #69707a;
    text-decoration: none;
  }
  .btn:focus {
    outline: 0;
    box-shadow: 0 0 0 0.25rem rgba(0, 97, 242, 0.25);
  }
  .btn:disabled {
    pointer-events: none;
    opacity: 0.65;
  }
  .btn-primary {
    color: #fff;
    background-color: #0061f2;
    border-color: #0061f2;
  }
  .btn-primary:hover {
    color: #fff;
    background-color: #0052ce;
    border-color: #004ec2;
  }
  .btn-primary:focus {
    color: #fff;
    background-color: #0052ce;
    border-color: #004ec2;
    box-shadow: 0 0 0 0.25rem rgba(38, 121, 244, 0.5);
  }
  .btn-primary:active {
    color: #fff;
    background-color: #004ec2;
    border-color: #0049b6;
  }
  .btn-primary:active:focus {
    box-shadow: 0 0 0 0.25rem rgba(38, 121, 244, 0.5);
  }
  .btn-primary:disabled {
    color: #fff;
    background-color: #0061f2;
    border-color: #0061f2;
  }
  .btn-secondary {
    color: #fff;
    background-color: #6900c7;
    border-color: #6900c7;
  }
  .btn-secondary:hover {
    color: #fff;
    background-color: #5900a9;
    border-color: #54009f;
  }
  .btn-secondary:focus {
    color: #fff;
    background-color: #5900a9;
    border-color: #54009f;
    box-shadow: 0 0 0 0.25rem rgba(128, 38, 207, 0.5);
  }
  .btn-secondary:active {
    color: #fff;
    background-color: #54009f;
    border-color: #4f0095;
  }
  .btn-secondary:active:focus {
    box-shadow: 0 0 0 0.25rem rgba(128, 38, 207, 0.5);
  }
  .btn-secondary:disabled {
    color: #fff;
    background-color: #6900c7;
    border-color: #6900c7;
  }
  .btn-light {
    color: #000;
    background-color: #f2f6fc;
    border-color: #f2f6fc;
  }
  .btn-light:hover {
    color: #000;
    background-color: #f4f7fc;
    border-color: #f3f7fc;
  }
  .btn-light:focus {
    color: #000;
    background-color: #f4f7fc;
    border-color: #f3f7fc;
    box-shadow: 0 0 0 0.25rem rgba(206, 209, 214, 0.5);
  }
  .btn-light:active {
    color: #000;
    background-color: #f5f8fd;
    border-color: #f3f7fc;
  }
  .btn-light:active:focus {
    box-shadow: 0 0 0 0.25rem rgba(206, 209, 214, 0.5);
  }
  .btn-light:disabled {
    color: #000;
    background-color: #f2f6fc;
    border-color: #f2f6fc;
  }
  .btn-dark {
    color: #fff;
    background-color: #212832;
    border-color: #212832;
  }
  .btn-dark:hover {
    color: #fff;
    background-color: #1c222b;
    border-color: #1a2028;
  }
  .btn-dark:focus {
    color: #fff;
    background-color: #1c222b;
    border-color: #1a2028;
    box-shadow: 0 0 0 0.25rem rgba(66, 72, 81, 0.5);
  }
  .btn-dark:active {
    color: #fff;
    background-color: #1a2028;
    border-color: #191e26;
  }
  .btn-dark:active:focus {
    box-shadow: 0 0 0 0.25rem rgba(66, 72, 81, 0.5);
  }
  .btn-dark:disabled {
    color: #fff;
    background-color: #212832;
    border-color: #212832;
  }
  .btn-white {
    color: #000;
    background-color: #fff;
    border-color: #fff;
  }
  .btn-white:hover {
    color: #000;
    background-color: #fff;
    border-color: #fff;
  }
  .btn-white:focus {
    color: #000;
    background-color: #fff;
    border-color: #fff;
    box-shadow: 0 0 0 0.25rem rgba(217, 217, 217, 0.5);
  }
  .btn-white:active {
    color: #000;
    background-color: #fff;
    border-color: #fff;
  }
  .btn-white:active:focus {
    box-shadow: 0 0 0 0.25rem rgba(217, 217, 217, 0.5);
  }
  .btn-white:disabled {
    color: #000;
    background-color: #fff;
    border-color: #fff;
  }
  .btn-teal {
    color: #fff;
    background-color: #00ba94;
    border-color: #00ba94;
  }
  .btn-teal:hover {
    color: #fff;
    background-color: #009e7e;
    border-color: #009576;
  }
  .btn-teal:focus {
    color: #fff;
    background-color: #009e7e;
    border-color: #009576;
    box-shadow: 0 0 0 0.25rem rgba(38, 196, 164, 0.5);
  }
  .btn-teal:active {
    color: #fff;
    background-color: #009576;
    border-color: #008c6f;
  }
  .btn-teal:active:focus {
    box-shadow: 0 0 0 0.25rem rgba(38, 196, 164, 0.5);
  }
  .btn-teal:disabled {
    color: #fff;
    background-color: #00ba94;
    border-color: #00ba94;
  }
  .btn-link {
    font-weight: 400;
    color: #0061f2;
    text-decoration: none;
  }
  .btn-link:hover {
    color: #004ec2;
    text-decoration: underline;
  }
  .btn-link:focus {
    text-decoration: underline;
  }
  .btn-link:disabled {
    color: #69707a;
  }
  .btn-lg {
    padding: 1.125rem 1.5rem;
    font-size: 1rem;
    border-radius: 0.5rem;
  }
  .fade {
    transition: opacity 0.15s linear;
  }
  @media (prefers-reduced-motion: reduce) {
    .fade {
      transition: none;
    }
  }
  .fade:not(.show) {
    opacity: 0;
  }
  .page-link {
    position: relative;
    display: block;
    color: #0061f2;
    background-color: #fff;
    border: 1px solid #d4dae3;
    transition: color 0.15s ease-in-out, background-color 0.15s ease-in-out,
      border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
  }
  @media (prefers-reduced-motion: reduce) {
    .page-link {
      transition: none;
    }
  }
  .page-link:hover {
    z-index: 2;
    color: #004ec2;
    text-decoration: none;
    background-color: #e0e5ec;
    border-color: #d4dae3;
  }
  .page-link:focus {
    z-index: 3;
    color: #004ec2;
    background-color: #e0e5ec;
    outline: 0;
    box-shadow: 0 0 0 0.25rem rgba(0, 97, 242, 0.25);
  }
  .page-item:not(:first-child) .page-link {
    margin-left: -1px;
  }
  .page-link {
    padding: 0.375rem 0.75rem;
  }
  .page-item:first-child .page-link {
    border-top-left-radius: 0.35rem;
    border-bottom-left-radius: 0.35rem;
  }
  .page-item:last-child .page-link {
    border-top-right-radius: 0.35rem;
    border-bottom-right-radius: 0.35rem;
  }
  .badge {
    display: inline-block;
    padding: 0.35em 0.65em;
    font-size: 0.75em;
    font-weight: 400;
    line-height: 1;
    color: #fff;
    text-align: center;
    white-space: nowrap;
    vertical-align: baseline;
    border-radius: 0.35rem;
  }
  .badge:empty {
    display: none;
  }
  .btn .badge {
    position: relative;
    top: -1px;
  }
  @-webkit-keyframes progress-bar-stripes {
    0% {
      background-position-x: 1rem;
    }
  }
  @keyframes progress-bar-stripes {
    0% {
      background-position-x: 1rem;
    }
  }
  @-webkit-keyframes spinner-border {
    to {
      transform: rotate(360deg);
    }
  }
  @keyframes spinner-border {
    to {
      transform: rotate(360deg);
    }
  }
  @-webkit-keyframes spinner-grow {
    0% {
      transform: scale(0);
    }
    50% {
      opacity: 1;
      transform: none;
    }
  }
  @keyframes spinner-grow {
    0% {
      transform: scale(0);
    }
    50% {
      opacity: 1;
      transform: none;
    }
  }
  @-webkit-keyframes placeholder-glow {
    50% {
      opacity: 0.2;
    }
  }
  @keyframes placeholder-glow {
    50% {
      opacity: 0.2;
    }
  }
  @-webkit-keyframes placeholder-wave {
    100% {
      -webkit-mask-position: -200% 0;
      mask-position: -200% 0;
    }
  }
  @keyframes placeholder-wave {
    100% {
      -webkit-mask-position: -200% 0;
      mask-position: -200% 0;
    }
  }
  .link-primary {
    color: #0061f2;
  }
  .link-primary:focus,
  .link-primary:hover {
    color: #004ec2;
  }
  .link-secondary {
    color: #6900c7;
  }
  .link-secondary:focus,
  .link-secondary:hover {
    color: #54009f;
  }
  .link-light {
    color: #f2f6fc;
  }
  .link-light:focus,
  .link-light:hover {
    color: #f5f8fd;
  }
  .link-dark {
    color: #212832;
  }
  .link-dark:focus,
  .link-dark:hover {
    color: #1a2028;
  }
  .link-white {
    color: #fff;
  }
  .link-white:focus,
  .link-white:hover {
    color: #fff;
  }
  .link-teal {
    color: #00ba94;
  }
  .link-teal:focus,
  .link-teal:hover {
    color: #009576;
  }
  .d-inline {
    display: inline !important;
  }
  .d-inline-block {
    display: inline-block !important;
  }
  .d-block {
    display: block !important;
  }
  .d-flex {
    display: flex !important;
  }
  .d-inline-flex {
    display: inline-flex !important;
  }
  .d-none {
    display: none !important;
  }
  .shadow {
    box-shadow: 0 0.15rem 1.75rem 0 rgba(33, 40, 50, 0.15) !important;
  }
  .shadow-lg {
    box-shadow: 0 1rem 3rem rgba(0, 0, 0, 0.175) !important;
  }
  .shadow-none {
    box-shadow: none !important;
  }
  .start-0 {
    left: 0 !important;
  }
  .start-50 {
    left: 50% !important;
  }
  .start-100 {
    left: 100% !important;
  }
  .end-0 {
    right: 0 !important;
  }
  .end-50 {
    right: 50% !important;
  }
  .end-100 {
    right: 100% !important;
  }
  .border {
    border: 1px solid #e0e5ec !important;
  }
  .border-0 {
    border: 0 !important;
  }
  .border-end {
    border-right: 1px solid #e0e5ec !important;
  }
  .border-end-0 {
    border-right: 0 !important;
  }
  .border-start {
    border-left: 1px solid #e0e5ec !important;
  }
  .border-start-0 {
    border-left: 0 !important;
  }
  .border-primary {
    border-color: #0061f2 !important;
  }
  .border-secondary {
    border-color: #6900c7 !important;
  }
  .border-light {
    border-color: #f2f6fc !important;
  }
  .border-dark {
    border-color: #212832 !important;
  }
  .border-white {
    border-color: #fff !important;
  }
  .border-teal {
    border-color: #00ba94 !important;
  }
  .border-1 {
    border-width: 1px !important;
  }
  .border-2 {
    border-width: 2px !important;
  }
  .border-3 {
    border-width: 3px !important;
  }
  .border-4 {
    border-width: 4px !important;
  }
  .border-5 {
    border-width: 5px !important;
  }
  .w-25 {
    width: 25% !important;
  }
  .w-50 {
    width: 50% !important;
  }
  .w-75 {
    width: 75% !important;
  }
  .w-100 {
    width: 100% !important;
  }
  .h-25 {
    height: 25% !important;
  }
  .h-50 {
    height: 50% !important;
  }
  .h-75 {
    height: 75% !important;
  }
  .h-100 {
    height: 100% !important;
  }
  .flex-fill {
    flex: 1 1 auto !important;
  }
  .flex-row {
    flex-direction: row !important;
  }
  .flex-shrink-0 {
    flex-shrink: 0 !important;
  }
  .flex-shrink-1 {
    flex-shrink: 1 !important;
  }
  .justify-content-start {
    justify-content: flex-start !important;
  }
  .justify-content-end {
    justify-content: flex-end !important;
  }
  .justify-content-center {
    justify-content: center !important;
  }
  .align-items-start {
    align-items: flex-start !important;
  }
  .align-items-end {
    align-items: flex-end !important;
  }
  .align-items-center {
    align-items: center !important;
  }
  .align-content-start {
    align-content: flex-start !important;
  }
  .align-content-end {
    align-content: flex-end !important;
  }
  .align-content-center {
    align-content: center !important;
  }
  .order-first {
    order: -1 !important;
  }
  .order-0 {
    order: 0 !important;
  }
  .order-1 {
    order: 1 !important;
  }
  .order-2 {
    order: 2 !important;
  }
  .order-3 {
    order: 3 !important;
  }
  .order-4 {
    order: 4 !important;
  }
  .order-5 {
    order: 5 !important;
  }
  .m-0 {
    margin: 0 !important;
  }
  .m-1 {
    margin: 0.25rem !important;
  }
  .m-2 {
    margin: 0.5rem !important;
  }
  .m-3 {
    margin: 1rem !important;
  }
  .m-4 {
    margin: 1.5rem !important;
  }
  .m-5 {
    margin: 2.5rem !important;
  }
  .m-10 {
    margin: 6rem !important;
  }
  .m-15 {
    margin: 9rem !important;
  }
  .my-0 {
    margin-top: 0 !important;
    margin-bottom: 0 !important;
  }
  .my-1 {
    margin-top: 0.25rem !important;
    margin-bottom: 0.25rem !important;
  }
  .my-2 {
    margin-top: 0.5rem !important;
    margin-bottom: 0.5rem !important;
  }
  .my-3 {
    margin-top: 1rem !important;
    margin-bottom: 1rem !important;
  }
  .my-4 {
    margin-top: 1.5rem !important;
    margin-bottom: 1.5rem !important;
  }
  .my-5 {
    margin-top: 2.5rem !important;
    margin-bottom: 2.5rem !important;
  }
  .my-10 {
    margin-top: 6rem !important;
    margin-bottom: 6rem !important;
  }
  .my-15 {
    margin-top: 9rem !important;
    margin-bottom: 9rem !important;
  }
  .mt-0 {
    margin-top: 0 !important;
  }
  .mt-1 {
    margin-top: 0.25rem !important;
  }
  .mt-2 {
    margin-top: 0.5rem !important;
  }
  .mt-3 {
    margin-top: 1rem !important;
  }
  .mt-4 {
    margin-top: 1.5rem !important;
  }
  .mt-5 {
    margin-top: 2.5rem !important;
  }
  .mt-10 {
    margin-top: 6rem !important;
  }
  .mt-15 {
    margin-top: 9rem !important;
  }
  .me-0 {
    margin-right: 0 !important;
  }
  .me-1 {
    margin-right: 0.25rem !important;
  }
  .me-2 {
    margin-right: 0.5rem !important;
  }
  .me-3 {
    margin-right: 1rem !important;
  }
  .me-4 {
    margin-right: 1.5rem !important;
  }
  .me-5 {
    margin-right: 2.5rem !important;
  }
  .me-10 {
    margin-right: 6rem !important;
  }
  .me-15 {
    margin-right: 9rem !important;
  }
  .mb-0 {
    color: #8b8686;
    margin-bottom: 0 !important;
  }
  .mb-1 {
    margin-bottom: 0.25rem !important;
  }
  .mb-2 {
    color: #fefefe;
    margin-bottom: 0.5rem !important;
  }
  .mb-3 {
    margin-bottom: 1rem !important;
  }
  .mb-4 {
    margin-bottom: 1.5rem !important;
  }
  .mb-5 {
    margin-bottom: 2.5rem !important;
  }
  .mb-10 {
    margin-bottom: 6rem !important;
  }
  .mb-15 {
    margin-bottom: 9rem !important;
  }
  .ms-0 {
    margin-left: 0 !important;
  }
  .ms-1 {
    margin-left: 0.25rem !important;
  }
  .ms-2 {
    margin-left: 0.5rem !important;
  }
  .ms-3 {
    margin-left: 1rem !important;
  }
  .ms-4 {
    margin-left: 1.5rem !important;
  }
  .ms-5 {
    margin-left: 2.5rem !important;
  }
  .ms-10 {
    margin-left: 6rem !important;
  }
  .ms-15 {
    margin-left: 9rem !important;
  }
  .p-0 {
    padding: 0 !important;
  }
  .p-1 {
    padding: 0.25rem !important;
  }
  .p-2 {
    padding: 0.5rem !important;
  }
  .p-3 {
    padding: 1rem !important;
  }
  .p-4 {
    padding: 1.5rem !important;
  }
  .p-5 {
    padding: 2.5rem !important;
  }
  .p-10 {
    padding: 6rem !important;
  }
  .p-15 {
    padding: 9rem !important;
  }
  .px-0 {
    padding-right: 0 !important;
    padding-left: 0 !important;
  }
  .px-1 {
    padding-right: 0.25rem !important;
    padding-left: 0.25rem !important;
  }
  .px-2 {
    padding-right: 0.5rem !important;
    padding-left: 0.5rem !important;
  }
  .px-3 {
    padding-right: 1rem !important;
    padding-left: 1rem !important;
  }
  .px-4 {
    padding-right: 1.5rem !important;
    padding-left: 1.5rem !important;
  }
  .px-5 {
    padding-right: 2.5rem !important;
    padding-left: 2.5rem !important;
  }
  .px-10 {
    padding-right: 6rem !important;
    padding-left: 6rem !important;
  }
  .px-15 {
    padding-right: 9rem !important;
    padding-left: 9rem !important;
  }
  .py-0 {
    padding-top: 0 !important;
    padding-bottom: 0 !important;
  }
  .py-1 {
    padding-top: 0.25rem !important;
    padding-bottom: 0.25rem !important;
  }
  .py-2 {
    padding-top: 0.5rem !important;
    padding-bottom: 0.5rem !important;
  }
  .py-3 {
    padding-top: 1rem !important;
    padding-bottom: 1rem !important;
  }
  .py-4 {
    padding-top: 1.5rem !important;
    padding-bottom: 1.5rem !important;
  }
  .py-5 {
    color: #ffffff;
    padding-top: 2.5rem !important;
    padding-bottom: 2.5rem !important;
  }
  .py-10 {
    padding-top: 6rem !important;
    padding-bottom: 6rem !important;
  }
  .py-15 {
    padding-top: 9rem !important;
    padding-bottom: 9rem !important;
  }
  .pt-0 {
    padding-top: 0 !important;
  }
  .pt-1 {
    padding-top: 0.25rem !important;
  }
  .pt-2 {
    padding-top: 0.5rem !important;
  }
  .pt-3 {
    padding-top: 1rem !important;
  }
  .pt-4 {
    padding-top: 1.5rem !important;
  }
  .pt-5 {
    padding-top: 2.5rem !important;
  }
  .pt-10 {
    padding-top: 6rem !important;
  }
  .pt-15 {
    padding-top: 9rem !important;
  }
  .fw-light {
    font-weight: 300 !important;
  }
  .text-start {
    text-align: left !important;
  }
  .text-end {
    text-align: right !important;
  }
  .text-center {
    text-align: center !important;
  }
  .text-primary {
    --bs-text-opacity: 1;
    color: rgba(var(--bs-primary-rgb), var(--bs-text-opacity)) !important;
  }
  .started {
    padding: 5rem 0 5rem 0;
}
  .text-secondary {
    --bs-text-opacity: 1;
    color: rgba(var(--bs-secondary-rgb), var(--bs-text-opacity)) !important;
  }
  .page-header-ui-dark .btn-link,
  .text-light {
    --bs-text-opacity: 1;
    color: rgba(var(--bs-light-rgb), var(--bs-text-opacity)) !important;
  }
  .page-header-ui-light .btn-link,
  .text-dark {
    --bs-text-opacity: 1;
    color: rgba(var(--bs-dark-rgb), var(--bs-text-opacity)) !important;
  }
  .text-white {
    --bs-text-opacity: 1;
    
    color: rgba(var(--bs-dark-rgb), var(--bs-text-opacity)) !important;
  }
  .text-teal {
    --bs-text-opacity: 1;
    color: rgba(var(--bs-teal-rgb), var(--bs-text-opacity)) !important;
  }
  .text-body {
    --bs-text-opacity: 1;
    color: rgba(var(--bs-body-color-rgb), var(--bs-text-opacity)) !important;
  }
  .page-header-ui-dark .page-header-ui-text,
  .text-white-50 {
    --bs-text-opacity: 1;
    color: rgba(28, 23, 23, 0.5) !important;
  }
  .bg-primary {
    --bs-bg-opacity: 1;
    background-color: rgba(
      var(--bs-primary-rgb),
      var(--bs-bg-opacity)
    ) !important;
  }
  .bg-secondary {
    --bs-bg-opacity: 1;
    background-color: rgba(
      var(--bs-secondary-rgb),
      var(--bs-bg-opacity)
    ) !important;
  }
  .bg-light {
    --bs-bg-opacity: 1;
    background-color: #3c1987!important;
}
  .bg-dark {
    background-color: #3c1987!important;
}
  .bg-white {
    --bs-bg-opacity: 1;
    background-color: rgba(var(--bs-white-rgb), var(--bs-bg-opacity)) !important;
  }
  .bg-teal {
    --bs-bg-opacity: 1;
    background-color: rgba(var(--bs-teal-rgb), var(--bs-bg-opacity)) !important;
  }
  .bg-body {
    --bs-bg-opacity: 1;
    background-color: rgba(
      var(--bs-body-bg-rgb),
      var(--bs-bg-opacity)
    ) !important;
  }
  .bg-transparent {
    --bs-bg-opacity: 1;
    background-color: transparent !important;
  }
  .bg-gradient {
    background-image: var(--bs-gradient) !important;
  }
  .rounded {
    border-radius: 0.35rem !important;
  }
  .rounded-0 {
    border-radius: 0 !important;
  }
  .rounded-1 {
    border-radius: 0.25rem !important;
  }
  .rounded-2 {
    border-radius: 0.35rem !important;
  }
  .rounded-3 {
    border-radius: 0.5rem !important;
  }
  .rounded-pill {
    border-radius: 50rem !important;
  }
  .rounded-end {
    border-top-right-radius: 0.35rem !important;
    border-bottom-right-radius: 0.35rem !important;
  }
  .rounded-start {
    border-bottom-left-radius: 0.35rem !important;
    border-top-left-radius: 0.35rem !important;
  }
  @media (min-width: 768px) {
    .d-md-inline {
      display: inline !important;
    }
    .d-md-inline-block {
      display: inline-block !important;
    }
    .d-md-block {
      display: block !important;
    }
    .d-md-flex {
      display: flex !important;
    }
    .d-md-inline-flex {
      display: inline-flex !important;
    }
    .d-md-none {
      display: none !important;
    }
    .flex-md-fill {
      flex: 1 1 auto !important;
    }
    .flex-md-row {
      flex-direction: row !important;
    }
    .flex-md-shrink-0 {
      flex-shrink: 0 !important;
    }
    .flex-md-shrink-1 {
      flex-shrink: 1 !important;
    }
    .justify-content-md-start {
      justify-content: flex-start !important;
    }
    .justify-content-md-end {
      justify-content: flex-end !important;
    }
    .justify-content-md-center {
      justify-content: center !important;
    }
    .align-items-md-start {
      align-items: flex-start !important;
    }
    .align-items-md-end {
      align-items: flex-end !important;
    }
    .align-items-md-center {
      align-items: center !important;
    }
    .align-content-md-start {
      align-content: flex-start !important;
    }
    .align-content-md-end {
      align-content: flex-end !important;
    }
    .align-content-md-center {
      align-content: center !important;
    }
    .order-md-first {
      order: -1 !important;
    }
    .order-md-0 {
      order: 0 !important;
    }
    .order-md-1 {
      order: 1 !important;
    }
    .order-md-2 {
      order: 2 !important;
    }
    .order-md-3 {
      order: 3 !important;
    }
    .order-md-4 {
      order: 4 !important;
    }
    .order-md-5 {
      order: 5 !important;
    }
    .m-md-0 {
      margin: 0 !important;
    }
    .m-md-1 {
      margin: 0.25rem !important;
    }
    .m-md-2 {
      margin: 0.5rem !important;
    }
    .m-md-3 {
      margin: 1rem !important;
    }
    .m-md-4 {
      margin: 1.5rem !important;
    }
    .m-md-5 {
      margin: 2.5rem !important;
    }
    .m-md-10 {
      margin: 6rem !important;
    }
    .m-md-15 {
      margin: 9rem !important;
    }
    .my-md-0 {
      margin-top: 0 !important;
      margin-bottom: 0 !important;
    }
    .my-md-1 {
      margin-top: 0.25rem !important;
      margin-bottom: 0.25rem !important;
    }
    .my-md-2 {
      margin-top: 0.5rem !important;
      margin-bottom: 0.5rem !important;
    }
    .my-md-3 {
      margin-top: 1rem !important;
      margin-bottom: 1rem !important;
    }
    .my-md-4 {
      margin-top: 1.5rem !important;
      margin-bottom: 1.5rem !important;
    }
    .my-md-5 {
      margin-top: 2.5rem !important;
      margin-bottom: 2.5rem !important;
    }
    .my-md-10 {
      margin-top: 6rem !important;
      margin-bottom: 6rem !important;
    }
    .my-md-15 {
      margin-top: 9rem !important;
      margin-bottom: 9rem !important;
    }
    .mt-md-0 {
      margin-top: 0 !important;
    }
    .mt-md-1 {
      margin-top: 0.25rem !important;
    }
    .mt-md-2 {
      margin-top: 0.5rem !important;
    }
    .mt-md-3 {
      margin-top: 1rem !important;
    }
    .mt-md-4 {
      margin-top: 1.5rem !important;
    }
    .mt-md-5 {
      margin-top: 2.5rem !important;
    }
    .mt-md-10 {
      margin-top: 6rem !important;
    }
    .mt-md-15 {
      margin-top: 9rem !important;
    }
    .me-md-0 {
      margin-right: 0 !important;
    }
    .me-md-1 {
      margin-right: 0.25rem !important;
    }
    .me-md-2 {
      margin-right: 0.5rem !important;
    }
    .me-md-3 {
      margin-right: 1rem !important;
    }
    .me-md-4 {
      margin-right: 1.5rem !important;
    }
    .me-md-5 {
      margin-right: 2.5rem !important;
    }
    .me-md-10 {
      margin-right: 6rem !important;
    }
    .me-md-15 {
      margin-right: 9rem !important;
    }
    .mb-md-0 {
      margin-bottom: 0 !important;
    }
    .mb-md-1 {
      margin-bottom: 0.25rem !important;
    }
    .mb-md-2 {
      margin-bottom: 0.5rem !important;
    }
    .mb-md-3 {
      margin-bottom: 1rem !important;
    }
    .mb-md-4 {
      margin-bottom: 1.5rem !important;
    }
    .mb-md-5 {
      margin-bottom: 2.5rem !important;
    }
    .mb-md-10 {
      margin-bottom: 6rem !important;
    }
    .mb-md-15 {
      margin-bottom: 9rem !important;
    }
    .ms-md-0 {
      margin-left: 0 !important;
    }
    .ms-md-1 {
      margin-left: 0.25rem !important;
    }
    .ms-md-2 {
      margin-left: 0.5rem !important;
    }
    .ms-md-3 {
      margin-left: 1rem !important;
    }
    .ms-md-4 {
      margin-left: 1.5rem !important;
    }
    .ms-md-5 {
      margin-left: 2.5rem !important;
    }
    .ms-md-10 {
      margin-left: 6rem !important;
    }
    .ms-md-15 {
      margin-left: 9rem !important;
    }
    .p-md-0 {
      padding: 0 !important;
    }
    .p-md-1 {
      padding: 0.25rem !important;
    }
    .p-md-2 {
      padding: 0.5rem !important;
    }
    .p-md-3 {
      padding: 1rem !important;
    }
    .p-md-4 {
      padding: 1.5rem !important;
    }
    .p-md-5 {
      padding: 2.5rem !important;
    }
    .p-md-10 {
      padding: 6rem !important;
    }
    .p-md-15 {
      padding: 9rem !important;
    }
    .px-md-0 {
      padding-right: 0 !important;
      padding-left: 0 !important;
    }
    .px-md-1 {
      padding-right: 0.25rem !important;
      padding-left: 0.25rem !important;
    }
    .px-md-2 {
      padding-right: 0.5rem !important;
      padding-left: 0.5rem !important;
    }
    .px-md-3 {
      padding-right: 1rem !important;
      padding-left: 1rem !important;
    }
    .px-md-4 {
      padding-right: 1.5rem !important;
      padding-left: 1.5rem !important;
    }
    .px-md-5 {
      padding-right: 2.5rem !important;
      padding-left: 2.5rem !important;
    }
    .px-md-10 {
      padding-right: 6rem !important;
      padding-left: 6rem !important;
    }
    .px-md-15 {
      padding-right: 9rem !important;
      padding-left: 9rem !important;
    }
    .py-md-0 {
      padding-top: 0 !important;
      padding-bottom: 0 !important;
    }
    .py-md-1 {
      padding-top: 0.25rem !important;
      padding-bottom: 0.25rem !important;
    }
    .py-md-2 {
      padding-top: 0.5rem !important;
      padding-bottom: 0.5rem !important;
    }
    .py-md-3 {
      padding-top: 1rem !important;
      padding-bottom: 1rem !important;
    }
    .py-md-4 {
      padding-top: 1.5rem !important;
      padding-bottom: 1.5rem !important;
    }
    .py-md-5 {
      padding-top: 2.5rem !important;
      padding-bottom: 2.5rem !important;
    }
    .py-md-10 {
      padding-top: 6rem !important;
      padding-bottom: 6rem !important;
    }
    .py-md-15 {
      padding-top: 9rem !important;
      padding-bottom: 9rem !important;
    }
    .pt-md-0 {
      padding-top: 0 !important;
    }
    .pt-md-1 {
      padding-top: 0.25rem !important;
    }
    .pt-md-2 {
      padding-top: 0.5rem !important;
    }
    .pt-md-3 {
      padding-top: 1rem !important;
    }
    .pt-md-4 {
      padding-top: 1.5rem !important;
    }
    .pt-md-5 {
      padding-top: 2.5rem !important;
    }
    .pt-md-10 {
      padding-top: 6rem !important;
    }
    .pt-md-15 {
      padding-top: 9rem !important;
    }
    .text-md-start {
      text-align: left !important;
    }
    .text-md-end {
      text-align: right !important;
    }
    .text-md-center {
      text-align: center !important;
    }
  }
  @media (min-width: 992px) {
    .d-lg-inline {
      display: inline !important;
    }
    .d-lg-inline-block {
      display: inline-block !important;
    }
    .d-lg-block {
      display: block !important;
    }
    .d-lg-flex {
      display: flex !important;
    }
    .d-lg-inline-flex {
      display: inline-flex !important;
    }
    .d-lg-none {
      display: none !important;
    }
    .flex-lg-fill {
      flex: 1 1 auto !important;
    }
    .flex-lg-row {
      flex-direction: row !important;
    }
    .flex-lg-shrink-0 {
      flex-shrink: 0 !important;
    }
    .flex-lg-shrink-1 {
      flex-shrink: 1 !important;
    }
    .justify-content-lg-start {
      justify-content: flex-start !important;
    }
    .justify-content-lg-end {
      justify-content: flex-end !important;
    }
    .justify-content-lg-center {
      justify-content: center !important;
    }
    .align-items-lg-start {
      align-items: flex-start !important;
    }
    .align-items-lg-end {
      align-items: flex-end !important;
    }
    .align-items-lg-center {
      align-items: center !important;
    }
    .align-content-lg-start {
      align-content: flex-start !important;
    }
    .align-content-lg-end {
      align-content: flex-end !important;
    }
    .align-content-lg-center {
      align-content: center !important;
    }
    .order-lg-first {
      order: -1 !important;
    }
    .order-lg-0 {
      order: 0 !important;
    }
    .order-lg-1 {
      order: 1 !important;
    }
    .order-lg-2 {
      order: 2 !important;
    }
    .order-lg-3 {
      order: 3 !important;
    }
    .order-lg-4 {
      order: 4 !important;
    }
    .order-lg-5 {
      order: 5 !important;
    }
    .m-lg-0 {
      margin: 0 !important;
    }
    .m-lg-1 {
      margin: 0.25rem !important;
    }
    .m-lg-2 {
      margin: 0.5rem !important;
    }
    .m-lg-3 {
      margin: 1rem !important;
    }
    .m-lg-4 {
      margin: 1.5rem !important;
    }
    .m-lg-5 {
      margin: 2.5rem !important;
    }
    .m-lg-10 {
      margin: 6rem !important;
    }
    .m-lg-15 {
      margin: 9rem !important;
    }
    .my-lg-0 {
      margin-top: 0 !important;
      margin-bottom: 0 !important;
    }
    .my-lg-1 {
      margin-top: 0.25rem !important;
      margin-bottom: 0.25rem !important;
    }
    .my-lg-2 {
      margin-top: 0.5rem !important;
      margin-bottom: 0.5rem !important;
    }
    .my-lg-3 {
      margin-top: 1rem !important;
      margin-bottom: 1rem !important;
    }
    .my-lg-4 {
      margin-top: 1.5rem !important;
      margin-bottom: 1.5rem !important;
    }
    .my-lg-5 {
      margin-top: 2.5rem !important;
      margin-bottom: 2.5rem !important;
    }
    .my-lg-10 {
      margin-top: 6rem !important;
      margin-bottom: 6rem !important;
    }
    .my-lg-15 {
      margin-top: 9rem !important;
      margin-bottom: 9rem !important;
    }
    .mt-lg-0 {
      margin-top: 0 !important;
    }
    .mt-lg-1 {
      margin-top: 0.25rem !important;
    }
    .mt-lg-2 {
      margin-top: 0.5rem !important;
    }
    .mt-lg-3 {
      margin-top: 1rem !important;
    }
    .mt-lg-4 {
      margin-top: 1.5rem !important;
    }
    .mt-lg-5 {
      margin-top: 2.5rem !important;
    }
    .mt-lg-10 {
      margin-top: 6rem !important;
    }
    .mt-lg-15 {
      margin-top: 9rem !important;
    }
    .me-lg-0 {
      margin-right: 0 !important;
    }
    .me-lg-1 {
      margin-right: 0.25rem !important;
    }
    .me-lg-2 {
      margin-right: 0.5rem !important;
    }
    .me-lg-3 {
      margin-right: 1rem !important;
    }
    .me-lg-4 {
      margin-right: 1.5rem !important;
    }
    .me-lg-5 {
      margin-right: 2.5rem !important;
    }
    .me-lg-10 {
      margin-right: 6rem !important;
    }
    .me-lg-15 {
      margin-right: 9rem !important;
    }
    .mb-lg-0 {
      margin-bottom: 0 !important;
    }
    .mb-lg-1 {
      margin-bottom: 0.25rem !important;
    }
    .mb-lg-2 {
      margin-bottom: 0.5rem !important;
    }
    .mb-lg-3 {
      margin-bottom: 1rem !important;
    }
    .mb-lg-4 {
      margin-bottom: 1.5rem !important;
    }
    .mb-lg-5 {
      margin-bottom: 2.5rem !important;
    }
    .mb-lg-10 {
      margin-bottom: 6rem !important;
    }
    .mb-lg-15 {
      margin-bottom: 9rem !important;
    }
    .ms-lg-0 {
      margin-left: 0 !important;
    }
    .ms-lg-1 {
      margin-left: 0.25rem !important;
    }
    .ms-lg-2 {
      margin-left: 0.5rem !important;
    }
    .ms-lg-3 {
      margin-left: 1rem !important;
    }
    .ms-lg-4 {
      margin-left: 1.5rem !important;
    }
    .ms-lg-5 {
      margin-left: 2.5rem !important;
    }
    .ms-lg-10 {
      margin-left: 6rem !important;
    }
    .ms-lg-15 {
      margin-left: 9rem !important;
    }
    .p-lg-0 {
      padding: 0 !important;
    }
    .p-lg-1 {
      padding: 0.25rem !important;
    }
    .p-lg-2 {
      padding: 0.5rem !important;
    }
    .p-lg-3 {
      padding: 1rem !important;
    }
    .p-lg-4 {
      padding: 1.5rem !important;
    }
    .p-lg-5 {
      padding: 2.5rem !important;
    }
    .p-lg-10 {
      padding: 6rem !important;
    }
    .p-lg-15 {
      padding: 9rem !important;
    }
    .px-lg-0 {
      padding-right: 0 !important;
      padding-left: 0 !important;
    }
    .px-lg-1 {
      padding-right: 0.25rem !important;
      padding-left: 0.25rem !important;
    }
    .px-lg-2 {
      padding-right: 0.5rem !important;
      padding-left: 0.5rem !important;
    }
    .px-lg-3 {
      padding-right: 1rem !important;
      padding-left: 1rem !important;
    }
    .px-lg-4 {
      padding-right: 1.5rem !important;
      padding-left: 1.5rem !important;
    }
    .px-lg-5 {
      padding-right: 2.5rem !important;
      padding-left: 2.5rem !important;
    }
    .px-lg-10 {
      padding-right: 6rem !important;
      padding-left: 6rem !important;
    }
    .px-lg-15 {
      padding-right: 9rem !important;
      padding-left: 9rem !important;
    }
    .py-lg-0 {
      padding-top: 0 !important;
      padding-bottom: 0 !important;
    }
    .py-lg-1 {
      padding-top: 0.25rem !important;
      padding-bottom: 0.25rem !important;
    }
    .py-lg-2 {
      padding-top: 0.5rem !important;
      padding-bottom: 0.5rem !important;
    }
    .py-lg-3 {
      padding-top: 1rem !important;
      padding-bottom: 1rem !important;
    }
    .py-lg-4 {
      padding-top: 1.5rem !important;
      padding-bottom: 1.5rem !important;
    }
    .py-lg-5 {
      padding-top: 2.5rem !important;
      padding-bottom: 2.5rem !important;
    }
    .py-lg-10 {
      padding-top: 6rem !important;
      padding-bottom: 6rem !important;
    }
    .py-lg-15 {
      padding-top: 9rem !important;
      padding-bottom: 9rem !important;
    }
    .pt-lg-0 {
      padding-top: 0 !important;
    }
    .pt-lg-1 {
      padding-top: 0.25rem !important;
    }
    .pt-lg-2 {
      padding-top: 0.5rem !important;
    }
    .pt-lg-3 {
      padding-top: 1rem !important;
    }
    .pt-lg-4 {
      padding-top: 1.5rem !important;
    }
    .pt-lg-5 {
      padding-top: 2.5rem !important;
    }
    .pt-lg-10 {
      padding-top: 6rem !important;
    }
    .pt-lg-15 {
      padding-top: 9rem !important;
    }
    .text-lg-start {
      text-align: left !important;
    }
    .text-lg-end {
      text-align: right !important;
    }
    .text-lg-center {
      text-align: center !important;
    }
  }
  @media (min-width: 1200px) {
    .d-xl-inline {
      display: inline !important;
    }
    .d-xl-inline-block {
      display: inline-block !important;
    }
    .d-xl-block {
      display: block !important;
    }
    .d-xl-flex {
      display: flex !important;
    }
    .d-xl-inline-flex {
      display: inline-flex !important;
    }
    .d-xl-none {
      display: none !important;
    }
    .flex-xl-fill {
      flex: 1 1 auto !important;
    }
    .flex-xl-row {
      flex-direction: row !important;
    }
    .flex-xl-shrink-0 {
      flex-shrink: 0 !important;
    }
    .flex-xl-shrink-1 {
      flex-shrink: 1 !important;
    }
    .justify-content-xl-start {
      justify-content: flex-start !important;
    }
    .justify-content-xl-end {
      justify-content: flex-end !important;
    }
    .justify-content-xl-center {
      justify-content: center !important;
    }
    .align-items-xl-start {
      align-items: flex-start !important;
    }
    .align-items-xl-end {
      align-items: flex-end !important;
    }
    .align-items-xl-center {
      align-items: center !important;
    }
    .align-content-xl-start {
      align-content: flex-start !important;
    }
    .align-content-xl-end {
      align-content: flex-end !important;
    }
    .align-content-xl-center {
      align-content: center !important;
    }
    .order-xl-first {
      order: -1 !important;
    }
    .order-xl-0 {
      order: 0 !important;
    }
    .order-xl-1 {
      order: 1 !important;
    }
    .order-xl-2 {
      order: 2 !important;
    }
    .order-xl-3 {
      order: 3 !important;
    }
    .order-xl-4 {
      order: 4 !important;
    }
    .order-xl-5 {
      order: 5 !important;
    }
    .m-xl-0 {
      margin: 0 !important;
    }
    .m-xl-1 {
      margin: 0.25rem !important;
    }
    .m-xl-2 {
      margin: 0.5rem !important;
    }
    .m-xl-3 {
      margin: 1rem !important;
    }
    .m-xl-4 {
      margin: 1.5rem !important;
    }
    .m-xl-5 {
      margin: 2.5rem !important;
    }
    .m-xl-10 {
      margin: 6rem !important;
    }
    .m-xl-15 {
      margin: 9rem !important;
    }
    .my-xl-0 {
      margin-top: 0 !important;
      margin-bottom: 0 !important;
    }
    .my-xl-1 {
      margin-top: 0.25rem !important;
      margin-bottom: 0.25rem !important;
    }
    .my-xl-2 {
      margin-top: 0.5rem !important;
      margin-bottom: 0.5rem !important;
    }
    .my-xl-3 {
      margin-top: 1rem !important;
      margin-bottom: 1rem !important;
    }
    .my-xl-4 {
      margin-top: 1.5rem !important;
      margin-bottom: 1.5rem !important;
    }
    .my-xl-5 {
      margin-top: 2.5rem !important;
      margin-bottom: 2.5rem !important;
    }
    .my-xl-10 {
      margin-top: 6rem !important;
      margin-bottom: 6rem !important;
    }
    .my-xl-15 {
      margin-top: 9rem !important;
      margin-bottom: 9rem !important;
    }
    .mt-xl-0 {
      margin-top: 0 !important;
    }
    .mt-xl-1 {
      margin-top: 0.25rem !important;
    }
    .mt-xl-2 {
      margin-top: 0.5rem !important;
    }
    .mt-xl-3 {
      margin-top: 1rem !important;
    }
    .mt-xl-4 {
      margin-top: 1.5rem !important;
    }
    .mt-xl-5 {
      margin-top: 2.5rem !important;
    }
    .mt-xl-10 {
      margin-top: 6rem !important;
    }
    .mt-xl-15 {
      margin-top: 9rem !important;
    }
    .me-xl-0 {
      margin-right: 0 !important;
    }
    .me-xl-1 {
      margin-right: 0.25rem !important;
    }
    .me-xl-2 {
      margin-right: 0.5rem !important;
    }
    .me-xl-3 {
      margin-right: 1rem !important;
    }
    .me-xl-4 {
      margin-right: 1.5rem !important;
    }
    .me-xl-5 {
      margin-right: 2.5rem !important;
    }
    .me-xl-10 {
      margin-right: 6rem !important;
    }
    .me-xl-15 {
      margin-right: 9rem !important;
    }
    .mb-xl-0 {
      margin-bottom: 0 !important;
    }
    .mb-xl-1 {
      margin-bottom: 0.25rem !important;
    }
    .mb-xl-2 {
      margin-bottom: 0.5rem !important;
    }
    .mb-xl-3 {
      margin-bottom: 1rem !important;
    }
    .mb-xl-4 {
      margin-bottom: 1.5rem !important;
    }
    .mb-xl-5 {
      margin-bottom: 2.5rem !important;
    }
    .mb-xl-10 {
      margin-bottom: 6rem !important;
    }
    .mb-xl-15 {
      margin-bottom: 9rem !important;
    }
    .ms-xl-0 {
      margin-left: 0 !important;
    }
    .ms-xl-1 {
      margin-left: 0.25rem !important;
    }
    .ms-xl-2 {
      margin-left: 0.5rem !important;
    }
    .ms-xl-3 {
      margin-left: 1rem !important;
    }
    .ms-xl-4 {
      margin-left: 1.5rem !important;
    }
    .ms-xl-5 {
      margin-left: 2.5rem !important;
    }
    .ms-xl-10 {
      margin-left: 6rem !important;
    }
    .ms-xl-15 {
      margin-left: 9rem !important;
    }
    .p-xl-0 {
      padding: 0 !important;
    }
    .p-xl-1 {
      padding: 0.25rem !important;
    }
    .p-xl-2 {
      padding: 0.5rem !important;
    }
    .p-xl-3 {
      padding: 1rem !important;
    }
    .p-xl-4 {
      padding: 1.5rem !important;
    }
    .p-xl-5 {
      padding: 2.5rem !important;
    }
    .p-xl-10 {
      padding: 6rem !important;
    }
    .p-xl-15 {
      padding: 9rem !important;
    }
    .px-xl-0 {
      padding-right: 0 !important;
      padding-left: 0 !important;
    }
    .px-xl-1 {
      padding-right: 0.25rem !important;
      padding-left: 0.25rem !important;
    }
    .px-xl-2 {
      padding-right: 0.5rem !important;
      padding-left: 0.5rem !important;
    }
    .px-xl-3 {
      padding-right: 1rem !important;
      padding-left: 1rem !important;
    }
    .px-xl-4 {
      padding-right: 1.5rem !important;
      padding-left: 1.5rem !important;
    }
    .px-xl-5 {
      padding-right: 2.5rem !important;
      padding-left: 2.5rem !important;
    }
    .px-xl-10 {
      padding-right: 6rem !important;
      padding-left: 6rem !important;
    }
    .px-xl-15 {
      padding-right: 9rem !important;
      padding-left: 9rem !important;
    }
    .py-xl-0 {
      padding-top: 0 !important;
      padding-bottom: 0 !important;
    }
    .py-xl-1 {
      padding-top: 0.25rem !important;
      padding-bottom: 0.25rem !important;
    }
    .py-xl-2 {
      padding-top: 0.5rem !important;
      padding-bottom: 0.5rem !important;
    }
    .py-xl-3 {
      padding-top: 1rem !important;
      padding-bottom: 1rem !important;
    }
    .py-xl-4 {
      padding-top: 1.5rem !important;
      padding-bottom: 1.5rem !important;
    }
    .py-xl-5 {
      padding-top: 2.5rem !important;
      padding-bottom: 2.5rem !important;
    }
    .py-xl-10 {
      padding-top: 6rem !important;
      padding-bottom: 6rem !important;
    }
    .py-xl-15 {
      padding-top: 9rem !important;
      padding-bottom: 9rem !important;
    }
    .pt-xl-0 {
      padding-top: 0 !important;
    }
    .pt-xl-1 {
      padding-top: 0.25rem !important;
    }
    .pt-xl-2 {
      padding-top: 0.5rem !important;
    }
    .pt-xl-3 {
      padding-top: 1rem !important;
    }
    .pt-xl-4 {
      padding-top: 1.5rem !important;
    }
    .pt-xl-5 {
      padding-top: 2.5rem !important;
    }
    .pt-xl-10 {
      padding-top: 6rem !important;
    }
    .pt-xl-15 {
      padding-top: 9rem !important;
    }
    .text-xl-start {
      text-align: left !important;
    }
    .text-xl-end {
      text-align: right !important;
    }
    .text-xl-center {
      text-align: center !important;
    }
  }
  body,
  html {
    height: 100%;
  }
  
  @-webkit-keyframes fadeInUp {
    0% {
      opacity: 0;
      margin-top: 0.75rem;
    }
    100% {
      opacity: 1;
      margin-top: 0;
    }
  }
  @keyframes fadeInUp {
    0% {
      opacity: 0;
      margin-top: 0.75rem;
    }
    100% {
      opacity: 1;
      margin-top: 0;
    }
  }
  @-webkit-keyframes fadeIn {
    0% {
      opacity: 0;
    }
    100% {
      opacity: 1;
    }
  }
  @keyframes fadeIn {
    0% {
      opacity: 0;
    }
    100% {
      opacity: 1;
    }
  }
  .bg-success {
    background-color: #3c1987!important;
}
  .bg-gradient-primary-to-secondary {
      background-color: #01989F !important;
      background-image: linear-gradient( 135deg, #00284C 0, rgba(105, 0, 199, 0.8) 100% ) !important;
  }
  .bg-transparent-light {
    color: rgba(255, 255, 255, 0.973) !important;
    background-color: rgba(0, 0, 0, 0.1) !important;
  }
  .bg-transparent-dark {
    color: rgba(33, 40, 50, 0.5) !important;
    background-color: rgba(33, 40, 50, 0.8) !important;
  }
  .bg-gray-100 {
    background-color: #f2f6fc !important;
  }
  .bg-gray-200 {
    background-color: #e0e5ec !important;
  }
  .bg-gray-300 {
    background-color: #d4dae3 !important;
  }
  .bg-gray-400 {
    background-color: #c5ccd6 !important;
  }
  .bg-gray-500 {
    background-color: #a7aeb8 !important;
  }
  .bg-gray-600 {
    background-color: #69707a !important;
  }
  .bg-gray-700 {
    background-color: #4a515b !important;
  }
  .bg-gray-800 {
    background-color: #363d47 !important;
  }
  .bg-gray-900 {
    background-color: #212832 !important;
  }
  .bg-white-25 {
    background-color: rgba(255, 255, 255, 0.25) !important;
  }
  .border-lg {
    border-width: 0.25rem !important;
  }
  .border-end-lg {
    border-right-width: 0.25rem !important;
  }
  .border-start-lg {
    border-left-width: 0.25rem !important;
  }
  .border-primary {
    border-color: #0061f2 !important;
  }
  .border-secondary {
    border-color: #6900c7 !important;
  }
  .border-light {
    border-color: #f2f6fc !important;
  }
  .border-dark {
    border-color: #1e6ddb !important;
  }
  .border-white {
    border-color: #fff !important;
  }
  .border-teal {
    border-color: #00ba94 !important;
  }
  .border-start-primary {
    border-left-color: #0061f2 !important;
  }
  .border-start-secondary {
    border-left-color: #6900c7 !important;
  }
  .border-start-light {
    border-left-color: #f2f6fc !important;
  }
  .border-start-dark {
    border-left-color: #2a75dd !important;
  }
  .border-start-white {
    border-left-color: #fff !important;
  }
  .border-start-teal {
    border-left-color: #00ba94 !important;
  }
  .border-end-primary {
    border-right-color: #0061f2 !important;
  }
  .border-end-secondary {
    border-right-color: #6900c7 !important;
  }
  .border-end-light {
    border-right-color: #f2f6fc !important;
  }
  .border-end-dark {
    border-right-color: #212832 !important;
  }
  .border-end-white {
    border-right-color: #fff !important;
  }
  .border-end-teal {
    border-right-color: #00ba94 !important;
  }
  .rounded-xl {
    border-radius: 1rem !important;
  }
  .border-gray-100 {
    border-color: #f2f6fc !important;
  }
  .border-gray-200 {
    border-color: #e0e5ec !important;
  }
  .border-gray-300 {
    border-color: #d4dae3 !important;
  }
  .border-gray-400 {
    border-color: #c5ccd6 !important;
  }
  .border-gray-500 {
    border-color: #a7aeb8 !important;
  }
  .border-gray-600 {
    border-color: #69707a !important;
  }
  .border-gray-700 {
    border-color: #4a515b !important;
  }
  .border-gray-800 {
    border-color: #363d47 !important;
  }
  .border-gray-900 {
    border-color: #212832 !important;
  }
  .shadow-right {
    box-shadow: 0.15rem 0 1.75rem 0 rgba(33, 40, 50, 0.15) !important;
  }
  .shadow-right-lg {
    box-shadow: 1rem 0 3rem 0 rgba(33, 40, 50, 0.15) !important;
  }
  .shadow-left {
    box-shadow: -0.15rem 0 1.75rem 0 rgba(33, 40, 50, 0.15) !important;
  }
  .shadow-left-lg {
    box-shadow: -1rem 0 3rem 0 rgba(33, 40, 50, 0.15) !important;
  }
  .content-skewed {
    perspective: 1500px !important;
    transform-style: preserve-3d !important;
  }
  .content-skewed-right {
    perspective-origin: right center !important;
  }
  .content-skewed-right .content-skewed-item {
    transform: rotateY(30deg) rotateX(15deg) !important;
    -webkit-backface-visibility: hidden !important;
    backface-visibility: hidden !important;
  }
  .content-skewed-left {
    perspective-origin: left center !important;
  }
  .content-skewed-left .content-skewed-item {
    transform: rotateY(-30deg) rotateX(15deg) !important;
    -webkit-backface-visibility: hidden !important;
    backface-visibility: hidden !important;
  }
  .text-gray-100 {
    color: #f2f6fc !important;
  }
  .text-gray-200 {
    color: #e0e5ec !important;
  }
  .text-gray-300 {
    color: #d4dae3 !important;
  }
  .text-gray-400 {
    color: #c5ccd6 !important;
  }
  .text-gray-500 {
    color: #a7aeb8 !important;
  }
  .text-gray-600 {
    color: #69707a !important;
  }
  .text-gray-700 {
    color: #4a515b !important;
  }
  .text-gray-800 {
    color: #363d47 !important;
  }
  .text-gray-900 {
    color: #212832 !important;
  }
  .fw-100 {
    font-weight: 100 !important;
  }
  .fw-200 {
    font-weight: 200 !important;
  }
  .fw-300 {
    font-weight: 300 !important;
  }
  .fw-400 {
    font-weight: 400 !important;
  }
  .fw-500 {
    font-weight: 500 !important;
  }
  .fw-600 {
    font-weight: 600 !important;
  }
  .fw-700 {
    font-weight: 700 !important;
  }
  .fw-800 {
    font-weight: 800 !important;
  }
  .fw-900 {
    font-weight: 900 !important;
  }
  .page-header-ui-dark .page-header-ui-text a,
  .text-white-75 {
    color: rgba(255, 255, 255, 0.75) !important;
  }
  .text-white-25 {
    color: rgba(255, 255, 255, 0.25) !important;
  }
  .text-lg {
    font-size: 1.25rem !important;
  }
  .text-xl {
    font-size: 2.5rem !important;
  }
  .text-arrow-icon {
    line-height: 1;
    display: inline-flex;
    align-items: center;
  }

 
  .pricing-header {
    color: #000;
    font-weight: 600;
    letter-spacing: 1px;
}
  .pricing-features {
    color: #94a1b1;
    font-weight: 600;
    letter-spacing: 1px;
    margin: 50px 0 25px;}
  .pricing-price {
      color: #2A356D;
      display: block;
      font-size: 32px;
      font-weight: 700;
  }
  .pricing-button.is-featured {
    background-color: #0061f2;;
    color: #fff;
}
.pricing-button {
    border: 1px solid #0061f2;;
    border-radius: 10px;
    color: #348efe;
    display: inline-block;
    margin: 25px 0;
    padding: 15px 35px;
    text-decoration: none;
    transition: all 150ms ease-in-out;
}
  .text-arrow-icon svg {
    margin-left: 0.25rem;
  }
  .text-arrow-icon.small svg {
    height: 0.875rem;
    width: 0.875rem;
  }
  .feather-lg {
    height: 1.25rem !important;
    width: 1.25rem !important;
  }
  .feather-xl {
    height: 2.5rem !important;
    width: 2.5rem !important;
  }
  .z-1 {
    z-index: 1 !important;
    position: relative !important;
  }
  .z-2 {
    z-index: 2 !important;
    position: relative !important;
  }
  .btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
  }
  .btn-icon {
    padding: 0;
    justify-content: center;
    overflow: hidden;
    border-radius: 100%;
    flex-shrink: 0;
    height: calc((0.875rem * 1) + (0.875rem * 2) + (2px)) !important;
    width: calc((0.875rem * 1) + (0.875rem * 2) + (2px)) !important;
  }
  .btn-icon .feather {
    margin-top: 0 !important;
  }
  .btn-icon.btn-xl {
    height: calc((1.125rem * 1) + (1.25rem * 2) + (2px)) !important;
    width: calc((1.125rem * 1) + (1.25rem * 2) + (2px)) !important;
    border-radius: 100%;
  }
  .btn-icon.btn-lg {
    height: calc((1rem * 1) + (1.125rem * 2) + (2px)) !important;
    width: calc((1rem * 1) + (1.125rem * 2) + (2px)) !important;
  }
  .btn-icon.btn-link {
    text-decoration: none;
  }
  .btn .feather {
    margin-top: -1px;
    height: 0.875rem;
    width: 0.875rem;
  }
  .btn-lg .feather {
    height: 1rem;
    width: 1rem;
  }
  .btn-xl .feather {
    height: 1.125rem;
    width: 1.125rem;
  }
  .btn-xl {
    padding: 1.25rem 1.5rem;
    font-size: 1.125rem;
    border-radius: 0.5rem;
  }
  .btn-transparent-dark {
    color: rgba(33, 40, 50, 0.5);
    background-color: transparent;
    border-color: transparent;
    color: rgba(33, 40, 50, 0.5) !important;
  }
  .btn-transparent-dark:hover {
    color: rgba(33, 40, 50, 0.5);
    background-color: rgba(33, 40, 50, 0.1);
    border-color: transparent;
  }
  .btn-transparent-dark:focus {
    color: rgba(33, 40, 50, 0.5);
    background-color: rgba(33, 40, 50, 0.1);
    border-color: transparent;
    box-shadow: 0 0 0 0.25rem rgba(11, 14, 17, 0.5);
  }
  .btn-transparent-dark:active {
    color: rgba(33, 40, 50, 0.5);
    background-color: rgba(33, 40, 50, 0.2);
    border-color: transparent;
  }
  .btn-transparent-dark:active:focus {
    box-shadow: 0 0 0 0.25rem rgba(11, 14, 17, 0.5);
  }
  .btn-transparent-dark:disabled {
    color: rgba(33, 40, 50, 0.35);
    background-color: rgba(33, 40, 50, 0.1);
    border-color: transparent;
  }
  .btn-transparent-dark:focus {
    box-shadow: 0 0 0 0.25rem rgba(33, 40, 50, 0.25) !important;
  }
  .btn-transparent-light {
    color: rgba(255, 255, 255, 0.5);
    background-color: transparent;
    border-color: transparent;
    color: rgba(255, 255, 255, 0.5) !important;
  }
  .btn-transparent-light:hover {
    color: rgba(255, 255, 255, 0.5);
    background-color: rgba(255, 255, 255, 0.1);
    border-color: transparent;
  }
  .btn-transparent-light:focus {
    color: rgba(255, 255, 255, 0.5);
    background-color: rgba(255, 255, 255, 0.1);
    border-color: transparent;
    box-shadow: 0 0 0 0.25rem rgba(88, 88, 88, 0.5);
  }
  .btn-transparent-light:active {
    color: rgba(255, 255, 255, 0.5);
    background-color: rgba(255, 255, 255, 0.2);
    border-color: transparent;
  }
  .btn-transparent-light:active:focus {
    box-shadow: 0 0 0 0.25rem rgba(88, 88, 88, 0.5);
  }
  .btn-transparent-light:disabled {
    color: rgba(255, 255, 255, 0.35);
    background-color: rgba(255, 255, 255, 0.1);
    border-color: transparent;
  }
  .btn-transparent-light:focus {
    box-shadow: 0 0 0 0.25rem rgba(255, 255, 255, 0.25) !important;
  }
  .btn-white-10 {
    color: rgba(255, 255, 255, 0.5);
    background-color: rgba(255, 255, 255, 0.1);
    border-color: transparent;
    color: rgba(255, 255, 255, 0.5) !important;
  }
  .btn-white-10:hover {
    color: rgba(255, 255, 255, 0.5);
    background-color: rgba(255, 255, 255, 0.15);
    border-color: transparent;
  }
  .btn-white-10:focus {
    color: rgba(255, 255, 255, 0.5);
    background-color: rgba(255, 255, 255, 0.15);
    border-color: transparent;
    box-shadow: 0 0 0 0.25rem rgba(88, 88, 88, 0.5);
  }
  .btn-white-10:active {
    color: rgba(255, 255, 255, 0.5);
    background-color: rgba(255, 255, 255, 0.2);
    border-color: transparent;
  }
  .btn-white-10:active:focus {
    box-shadow: 0 0 0 0.25rem rgba(88, 88, 88, 0.5);
  }
  .btn-white-10:disabled {
    color: rgba(255, 255, 255, 0.35);
    background-color: rgba(255, 255, 255, 0.1);
    border-color: transparent;
  }
  .btn-white-10:focus {
    box-shadow: 0 0 0 0.25rem rgba(255, 255, 255, 0.25) !important;
  }
  .feather {
    height: 1rem;
    width: 1rem;
    vertical-align: top;
  }
  .icon-stack {
    display: inline-flex;
    justify-content: center;
    align-items: center;
    border-radius: 100%;
    height: 2.5rem;
    width: 2.5rem;
    font-size: 1rem;
    background-color: #f2f6fc;
    flex-shrink: 0;
  }
  .icon-stack svg {
    height: 1rem;
    width: 1rem;
  }
  .icon-stack-lg {
    height: 4rem;
    width: 4rem;
    font-size: 1.5rem;
  }
  .icon-stack-lg svg {
    height: 1.5rem;
    width: 1.5rem;
  }
  .icon-stack-xl {
    height: 5rem;
    width: 5rem;
    font-size: 1.75rem;
  }
  .icon-stack-xl svg {
    height: 1.75rem;
    width: 1.75rem;
  }
  .badge-md {
    font-size: 1rem;
  }
  .badge-lg {
    font-size: 1.25rem;
  }
  .content-skewed {
    perspective: 1500px;
    transform-style: preserve-3d;
  }
  .content-skewed-right {
    perspective-origin: right center;
  }
  .content-skewed-right .content-skewed-item {
    transform: rotateY(30deg) rotateX(15deg);
    -webkit-backface-visibility: hidden;
    backface-visibility: hidden;
  }
  .content-skewed-left {
    perspective-origin: left center;
  }
  .content-skewed-left .content-skewed-item {
    transform: rotateY(-30deg) rotateX(15deg);
    -webkit-backface-visibility: hidden;
    backface-visibility: hidden;
  }
  .badge-marketing {
    padding: 0.5em 1em;
  }
  section {
    position: relative;
  }
  .svg-border-rounded svg {
    position: absolute;
    bottom: 0;
    left: 0;
    height: 1rem;
    width: 100%;
  }
  @media (min-width: 576px) {
    .svg-border-rounded svg {
      height: 1.5rem;
    }
  }
  @media (min-width: 768px) {
    .svg-border-rounded svg {
      height: 2rem;
    }
  }
  @media (min-width: 992px) {
    .svg-border-rounded svg {
      height: 2.5rem;
    }
  }
  @media (min-width: 1200px) {
    .svg-border-rounded svg {
      height: 3rem;
    }
  }
  .device {
    position: relative;
    background-size: cover;
  }
  .device::after {
    position: absolute;
    background-size: cover;
    width: 100%;
    height: 100%;
    pointer-events: none;
  }
  .device[data-device="iPhoneX"][data-orientation="portrait"][data-color="black"] {
    padding-bottom: 198.89807163%;
    background-image: url(/assets/img/device-mockups/iPhoneX/portrait.png);
    z-index: initial;
  }
  .device[data-device="iPhoneX"][data-orientation="landscape"][data-color="black"] {
    padding-bottom: 50.27700831%;
    background-image: url(/assets/img/device-mockups/iPhoneX/landscape.png);
    z-index: initial;
  }
  .device[data-device="iPhoneX"][data-orientation="portrait"][data-color="black"] {
    padding-bottom: 198.898071625%;
  }
  .device[data-device="iPhoneX"][data-orientation="portrait"][data-color="black"]::after {
    content: "";
    background-image: url(/assets/img/device-mockups/iPhoneX/portrait_black.png);
  }
  .device[data-device="iPhoneX"][data-orientation="landscape"][data-color="black"] {
    padding-bottom: 50.2770083102%;
  }
  .device[data-device="iPhoneX"][data-orientation="landscape"][data-color="black"]::after {
    content: "";
    background-image: url(/assets/img/device-mockups/iPhoneX/landscape_black.png);
  }
  .page-header-ui {
    position: relative;
    padding-top: 8rem;
    padding-bottom: 8rem;
  }
  .page-header-ui .page-header-ui-content .page-header-ui-title {
    font-size: 2.5rem;
  }
  .page-header-ui .page-header-ui-content .page-header-ui-text {
    font-size: 1.15rem;
  }
  .page-header-ui .page-header-ui-content .page-header-ui-text.small {
    font-size: 0.9rem;
  }
  .page-header-ui-dark {
    color: #fff;
    background-color: #212832;
  }
  .page-header-ui-dark .page-header-ui-title {
    color: #fff;
  }
  .page-header-ui-light {
    background-color: #f2f6fc;
  }
  .page-header-ui-light .page-header-ui-text {
    color: #69707a;
  }
  .page-header-ui-light .page-header-ui-text a {
    color: #4a515b;
  }
  
  .container1 {
    margin: 0 auto;
    padding: 50px 0 0;
    max-width: 960px;
    width: 100%;
  }
  .container2 {
    margin: 0 auto;
    padding: 1px 0 0;
    max-width: 96px;
    width: 100%;
  }
  
@media (max-width: 991px){
  .navbar .container{
      display: flex;
      justify-content: start; 
  }
  .navbar{
      position: relative;  
      
  }
  .navbar .navbar-toggler{
      position: absolute;
      right: 1rem;
      top: .6rem;
  }

}
.brand-img {
 
  
  transition: .5s;
}
.img-fluid {
  max-width: 100%;
  height: auto;
}
img, svg {
  vertical-align: middle;
}
.row {
  --bs-gutter-x: 1.5rem;
  --bs-gutter-y: 0;
  display: flex;
  flex-wrap: wrap;
  margin-top: calc(var(--bs-gutter-y) * -1);
  margin-right: calc(var(--bs-gutter-x)/ -2);
  margin-left: calc(var(--bs-gutter-x)/ -2);
}

</style>
